import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

public class TestOtp {

	
	public static void main(String args[])throws Exception
	{
		 
		HttpResponse<String> response = Unirest.get("http://2factor.in/API/V1/a7a65ea8-53e2-11e9-a6e1-0200cd936042/SMS/9032501675/4499")
				  .header("content-type", "application/x-www-form-urlencoded")
				  .asString();
	
	}
}
