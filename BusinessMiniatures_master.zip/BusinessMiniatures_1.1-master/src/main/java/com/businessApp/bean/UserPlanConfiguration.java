package com.businessApp.bean;

import org.springframework.stereotype.Component;

@Component
public class UserPlanConfiguration
{

	private String uId;
	private String subId;
	private String otp;
	private String id;
	private String deviceID;
	private String osType;

	public String getuId()
	{
		return uId;
	}

	public void setuId(String uId)
	{
		this.uId = uId;
	}

	public String getSubId()
	{
		return subId;
	}

	public void setSubId(String subId)
	{
		this.subId = subId;
	}

	public String getDeviceID()
	{
		return deviceID;
	}

	public void setDeviceID(String deviceID)
	{
		this.deviceID = deviceID;
	}

	public String getOsType()
	{
		return osType;
	}

	public void setOsType(String osType)
	{
		this.osType = osType;
	}

	public String getOtp()
	{
		return otp;
	}

	public void setOtp(String otp)
	{
		this.otp = otp;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

}
