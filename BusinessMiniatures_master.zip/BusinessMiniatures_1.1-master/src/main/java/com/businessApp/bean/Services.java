package com.businessApp.bean;

import org.springframework.stereotype.Component;

@Component
public class Services
{
	private String serviceId;
	private String serviceName;
	private String description;
	private int duration;
	private double price;
	private int renewalTime;

	public String getServiceId()
	{
		return this.serviceId;
	}

	public void setServiceId(String serviceId)
	{
		this.serviceId = serviceId;
	}

	public String getServiceName()
	{
		return this.serviceName;
	}

	public void setServiceName(String serviceName)
	{
		this.serviceName = serviceName;
	}

	public String getDescription()
	{
		return this.description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public int getDuration()
	{
		return this.duration;
	}

	public void setDuration(int duration)
	{
		this.duration = duration;
	}

	public double getPrice()
	{
		return this.price;
	}

	public void setPrice(double price)
	{
		this.price = price;
	}

	public int getRenewalTime()
	{
		return renewalTime;
	}

	public void setRenewalTime(int renewalTime)
	{
		this.renewalTime = renewalTime;
	}

}
