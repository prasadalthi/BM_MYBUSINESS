package com.businessApp.bean;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.businessApp.model.MenuDetails;
import com.businessApp.model.User;
@Component
public class LoginResult
{
	private User userData;
	private List<Object> businessData;
	private List<MenuDetails> menuData;

	public LoginResult() {

		this.businessData = new ArrayList<>();
		this.menuData = new ArrayList<>();
	}

	public User getUserData()
	{
		return this.userData;
	}
	public void setUserData(User userData)
	{
		this.userData = userData;
	}
	public List<Object> getBusinessData()
	{
		return this.businessData;
	}
	public void setBusinessData(List<Object> businessData)
	{
		this.businessData = businessData;
	}

	public List<MenuDetails> getMenuData()
	{
		return this.menuData;
	}

	public void setMenuData(List<MenuDetails> menuData)
	{
		this.menuData = menuData;
	}

}
