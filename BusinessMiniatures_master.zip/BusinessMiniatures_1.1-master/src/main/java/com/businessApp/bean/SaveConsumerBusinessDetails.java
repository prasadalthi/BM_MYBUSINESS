package com.businessApp.bean;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class SaveConsumerBusinessDetails
{

	private String id;
	private String bId;
	private String macId;
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date modifiedTime;
	public String getMacId()
	{
		return this.macId;
	}
	public void setMacId(String macId)
	{
		this.macId = macId;
	}
	public String getId()
	{
		return this.id;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public String getbId()
	{
		return this.bId;
	}
	public void setbId(String bId)
	{
		this.bId = bId;
	}
	public Date getModifiedTime()
	{
		return this.modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime)
	{
		this.modifiedTime = modifiedTime;
	}

}
