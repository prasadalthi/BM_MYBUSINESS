package com.businessApp.bean;

import org.springframework.stereotype.Component;

@Component
public class TestBean {
	
	int i;
	@Override
	public String toString() {
		return "TestBean [i=" + i + ", h=" + h + "]";
	}
	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
	public String getH() {
		return h;
	}
	public void setH(String h) {
		this.h = h;
	}
	String h;

}
