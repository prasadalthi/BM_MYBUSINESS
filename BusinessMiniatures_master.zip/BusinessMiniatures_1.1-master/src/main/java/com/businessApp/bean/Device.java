package com.businessApp.bean;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Component;

@Component
public class Device
{

	private String deviceID;
	private String token;
	private String osType;

	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date loginTime;

	public String getDeviceID()
	{
		return deviceID;
	}

	public void setDeviceID(String deviceID)
	{
		this.deviceID = deviceID;
	}

	public String getToken()
	{
		return token;
	}

	public void setToken(String token)
	{
		this.token = token;
	}

	public Date getLoginTime()
	{
		return loginTime;
	}

	public void setLoginTime(Date loginTime)
	{
		this.loginTime = loginTime;
	}

	public String getOsType()
	{
		return osType;
	}

	public void setOsType(String osType)
	{
		this.osType = osType;
	}

}