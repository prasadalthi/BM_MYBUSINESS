package com.businessApp.bean;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.businessApp.model.AppointmentCalendar;
import com.businessApp.model.Messages;
import com.businessApp.service.AndroidPushNotificationsService;
import com.businessApp.service.PublisherBusinessEmployeeService;
import com.businessApp.service.PublisherService;
import com.businessApp.service.UserService;

@Component
public class ScheduledTasks
{
	@Autowired
	PublisherBusinessEmployeeService pBEmpService;
	@Autowired
	PublisherService pubService;

	@Autowired
	UserService userService;
	@Autowired
	Messages message;

	@Autowired
	AndroidPushNotificationsService fcm;

	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

	// @Scheduled(cron = "0 6 * * *")
	// @Scheduled(cron = "*/10 * * * * *")
	public void performTaskUsingCron() throws Exception
	{
		List<AppointmentCalendar> appData;// = this.pBEmpService.getAppoinmentForNotification();
		// if (!appData.isEmpty())
		// {
		// int type = 1;
		// String message = null;
		// String title = null;
		// for (int i = 0; i < appData.size(); i++)
		// {
		//
		// if (appData.get(i).getConsumerId() != null)
		// {
		//
		// User receiver = userService.getUserById(appData.get(i).getConsumerId());
		//
		// if (receiver.getToken() != null)
		// {
		// Date dateNow = new Date();
		//
		// // User sender = userService.getUserById(appData.get(i).getPublisherId());
		//
		// PublisherBusiness pbData =
		// this.pBEmpService.getBusinessDetails(appData.get(i).getBusinessId(),
		// appData.get(i).getPublisherId());
		// List<String> serviceDetais = this.pBEmpService.getServiceDetails(pbData,
		// appData.get(i).getServiceId());
		//
		// String date = this.pBEmpService
		// .toChangeDateToLocalFormat(appData.get(i).getStartScheduledTime().toString());
		//
		// message = "Today Appointment got scheduled for " + pbData.getName() + " "
		// + serviceDetais.get(0) + " at " + date + ".";
		//
		// title = "Appointment Scheduled";
		//
		// this.message.setCreatedTime(dateNow);
		// this.message.setuId(pbData.getPublisherId());
		// this.message.setbId(pbData.getId());
		// this.message.setReceiverID(appData.get(i).getConsumerId());
		// this.message.setMessage(message);
		// this.message.setFrom(pbData.getName());
		// this.message.setTo(appData.get(i).getName());
		// this.message.setTitle(title);
		// fcm.sendAppointmentNotification(receiver.getToken(), this.message, type);
		// }
		//
		// }
		//
		// }
		//
		// }

	}

	// @Scheduled(fixedRate = 10000)
	// public void performTask()
	// {
	//
	// System.out.println("Regular task performed at " + dateFormat.format(new
	// Date()));
	//
	// }
	//
	// @Scheduled(initialDelay = 1000, fixedRate = 10000)
	// public void performDelayedTask()
	// {
	//
	// System.out.println("Delayed Regular task performed at " +
	// dateFormat.format(new Date()));
	//
	// }
}
