package com.businessApp.bean;

public class UserSubscriptionBean
{
	private String publisherId;
	private String planId;

	public String getPublisherId()
	{
		return publisherId;
	}

	public void setPublisherId(String publisherId)
	{
		this.publisherId = publisherId;
	}

	public String getPlanId()
	{
		return planId;
	}

	public void setPlanId(String planId)
	{
		this.planId = planId;
	}

}
