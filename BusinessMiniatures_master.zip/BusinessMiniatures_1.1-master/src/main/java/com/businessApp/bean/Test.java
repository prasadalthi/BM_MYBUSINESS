package com.businessApp.bean;

import java.util.HashMap;

import org.springframework.stereotype.Component;
@Component
public class Test {
	
	String name;
	@Override
	public String toString() {
		return "Test [name=" + name + ", data=" + data + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public HashMap<String,TestBean> data=new HashMap<>();

	public HashMap<String, TestBean> getData() {
		return data;
	}

	public void setData(HashMap<String, TestBean> data) {
		this.data = data;
	}

}
