package com.businessApp.bean;

public class QRCodeBean
{
	private String id;
	private String qrCode;
	public String getId()
	{
		return this.id;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public String getQrCode()
	{
		return this.qrCode;
	}
	public void setQrCode(String qrCode)
	{
		this.qrCode = qrCode;
	}

}
