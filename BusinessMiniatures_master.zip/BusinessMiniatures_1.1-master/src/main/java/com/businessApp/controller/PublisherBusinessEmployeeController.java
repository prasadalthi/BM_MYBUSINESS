package com.businessApp.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.businessApp.bean.AddPto;
import com.businessApp.bean.AppointmentBean;
import com.businessApp.bean.ResponseBean;
import com.businessApp.bean.Services;
import com.businessApp.constants.StatusConstants;
import com.businessApp.model.AppointmentCalendar;
import com.businessApp.model.EmployeePto;
import com.businessApp.model.PublisherBusinessEmployee;
import com.businessApp.model.TrackReport;
import com.businessApp.service.PublisherBusinessEmployeeService;
import com.businessApp.service.UserService;

@RestController

@RequestMapping(value = "/publisher")
public class PublisherBusinessEmployeeController
{
	private static Logger logger = LoggerFactory.getLogger(PublisherBusinessEmployeeController.class);

	@Value("${upload.user.folderPath}")
	//private String dir;

	private String dir = "https://s3.console.aws.amazon.com/s3/buckets/bmsimage/images/BusinessMiniatures/src/main/uploads";

	String url = "https://s3.console.aws.amazon.com/s3/buckets/bmsimage/images/BusinessMiniatures/publisher/employee/geticon/";

	@Autowired
	PublisherBusinessEmployeeService pubEmpService;

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	TrackReport trackReport;

	@Autowired
	UserService userService;

	/**
	 * To create the employee user a publisher business and publisher
	 * 
	 * @param publBusinessEmployee
	 * @return To get the message like "Employee has been successfully created"
	 */
	@PostMapping(path = "/employee/create", consumes = "application/json")
	public ResponseBean employeeCreate(@RequestBody PublisherBusinessEmployee publBusinessEmployee)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			if (publBusinessEmployee.getCreatedTime() == null)
			{
				Date dt = new Date();
				publBusinessEmployee.setCreatedTime(dt);
				publBusinessEmployee.setUpdatedTime(dt);
				publBusinessEmployee.setIcon("");

			}

			PublisherBusinessEmployee emp = this.pubEmpService.save(publBusinessEmployee);

			respBean.setCode(StatusConstants.SUCCESS_CODE);
			respBean.setMessage("Employee has been successfully created");
			respBean.setResult(publBusinessEmployee);
		}
		catch (Exception e)
		{

			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * To update the employee based on employee object
	 * 
	 * @param publBusinessEmployee
	 * @return To get the message like "Employee has been successfully updated"
	 */
	@PutMapping(path = "/employee/update", consumes = "application/json")
	public ResponseBean updateEmployee(@RequestBody PublisherBusinessEmployee publBusinessEmployee)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			if (publBusinessEmployee.getUpdatedTime() == null)
			{
				publBusinessEmployee.setUpdatedTime(new java.util.Date());
			}

			String report = this.pubEmpService.updateEmployee(publBusinessEmployee);

			if (report.equals("INVALID"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Invalid details !");
				respBean.setResult(null);

			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Employee has been successfully updated");
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	/**
	 * To get list of all employees based on publisherId and BusinessId otherwise
	 * get all employees
	 * 
	 * @param publisherId,
	 *            BusinessId
	 * @return To get list of all employees based on publisherId and BusinessId
	 */
	@PostMapping(path = "/employee/list", consumes = "application/json", produces = "application/json")
	public ResponseBean getList(@RequestBody PublisherBusinessEmployee pBE)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			List<PublisherBusinessEmployee> list = this.pubEmpService.employeeList(pBE.getBusinessId(),
			        pBE.getPublisherId());

			if ((list != null) && !(list.isEmpty()))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(list);
			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No employee data found !");
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	/**
	 * To Create the Appointment
	 * 
	 * @param appointBean
	 * @return To get the message like "Appointment has been create successfully"
	 */
	@PostMapping(path = "/employee/saveappointment", consumes = "application/json")
	public ResponseBean saveAppointment(@RequestBody AppointmentBean appointBean)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			String appType = "NEW";

			Map<String, String> report = this.pubEmpService.createAppointment(appointBean, appType);

			logger.info("report ----------" + report.get("message"));
			logger.info("Id ----------" + report.get("trackId"));

			if (report.containsKey("message"))
			{

				List<Integer> details = this.pubEmpService.getAppointmentDetails(appointBean);

				if ("INVALID_DETAILS".equals(report.get("message")))

				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("No business found !");
					respBean.setResult(null);

				}

				else if ("HOLI_DAY".equals(report.get("message")))
				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("Sorry today is holiday! Please select another date ");
					respBean.setResult(null);
				}

				else if ("NotWorkingHours".equals(report.get("message")))
				{
					int s = details.get(details.size() - 2);
					int e = details.get(details.size() - 1);

					int sHour = s / 60;
					int sminute = s % 60;

					int eHour = e / 60;
					int eminute = e % 60;

					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("Sorry, Plz select business hours between " + sHour + ":" + sminute + "  To "
					        + eHour + ":" + eminute);
					respBean.setResult(null);

				}

				else if ("TimesMismatched".equals(report.get("message")))
				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("Appointment end time must be greater than start time !");
					respBean.setResult(null);
				}

				else if ("LIST_EMPTY".equals(report.get("message")))
				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("Employee not available!");
					respBean.setResult(null);
				}

				else if ("NO_SERVICE".equals(report.get("message")))
				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("Employee service not started !");
					respBean.setResult(null);
				}

				else if ("NO_FIT".equals(report.get("message")))
				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("Time is  not sufficient for the service, you chosen !");
					respBean.setResult(null);
				}

				else if ("BREAK".equals(report.get("message")))
				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("Break Time !");
					respBean.setResult(null);
				}

				else if ("ALL_BOOKED".equals(report.get("message")))
				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("All services booked ! Please select another time !");
					respBean.setResult(null);
				}

				else
				{
					respBean.setCode(StatusConstants.SUCCESS_CODE);
					respBean.setMessage("Appointment got scheduled successfully");
					respBean.setResult(null);
				}
				details.clear();
			}

			if (report.containsKey("trackId"))
			{
				this.trackReport.setId(report.get("trackId"));
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		this.trackReport.setResponce(respBean);
		this.userService.updateTrackReport(this.trackReport);

		return respBean;
	}

	/**
	 * To create Appointment Calender details
	 * 
	 * @param calender
	 * @return
	 */
	@PostMapping(path = "/employee/calender", consumes = "application/json")
	public ResponseBean calenderCreate(@RequestBody AppointmentCalendar calender)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			this.pubEmpService.save(calender);

			respBean.setCode(StatusConstants.SUCCESS_CODE);
			respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
			respBean.setResult(null);

		}
		catch (Exception e)
		{

			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * To delete the employee based on employeeId
	 * 
	 * @param employeeId
	 * @return To get message like "Employee has been successfully deleted"
	 */
	@DeleteMapping(value = "/employee/delete/{id}", produces = "application/json")
	public ResponseBean removeEmployeeById(@PathVariable("id") String employeeId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			String report = this.pubEmpService.deleteEmployeeById(employeeId);

			if (report.equals("INVALID"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Employee not found !");
				respBean.setResult(null);
			}

			else if (report.equals("UNSUCCESS"))
			{

				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Employee not found !");
				respBean.setResult(null);

			}

			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Employee has been deleted successfully");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * To list the all appointments in a particular date and PublisherId
	 * 
	 * @param AppointmentCalendar
	 *            object
	 * 
	 * @return To list the all appointments in a particular date and PublisherId
	 */
	@PostMapping(path = "/getappointment/", produces = "application/json", consumes = "application/json")
	public ResponseBean listOfEmpAppointmentsByDate(@RequestBody AppointmentBean appCla)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			Object report = this.pubEmpService.listOfEmpAppointmentsByDate(appCla);

			if (report.equals("Holiday"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Today  is holiday");
				respBean.setResult(null);
			}

			else if (report.equals("INVALID_BUSINESS"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No  business  found !");
				respBean.setResult(null);
			}

			else if (report.equals("No_Employee_Found"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No employee available !");
				respBean.setResult(null);
			}

			else if (report.equals("DETAILS_REQUIRED"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Details required !");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(report);
			}

		}
		catch (Exception e)
		{

			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * To Create Employee PTO Detalis
	 * 
	 * @param pto
	 * @return
	 */
	@PostMapping(path = "/employee/savepto/", produces = "application/json", consumes = "application/json")
	public ResponseBean saveEmployeeTimeOff(@RequestBody EmployeePto pto)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			Object result = this.pubEmpService.saveEmployeeTimeOff(pto);

			if ("SUCCESS".equals(result))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("PTO details has been successfully stored");
				respBean.setResult(null);
			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Employee PTO details already exist !");
				respBean.setResult(result);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	/**
	 * 
	 * To Update PTO Detalis
	 * 
	 * @param updatePto
	 * @return
	 */
	@PutMapping(path = "/employee/updatepto", consumes = "application/json")
	public ResponseBean updateEmployeeTimeOff(@RequestBody EmployeePto updatePto)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			String report = this.pubEmpService.updateEmployeeTimeOff(updatePto);

			if (report.equals("INVALID"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Invalid Data !  PTO details  has not been  updated");
				respBean.setResult(null);

			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("PTO details  has been successfully updated");
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	/**
	 * 
	 * To Remove PTO Details to the Particular Employee
	 * 
	 * @param removePto
	 * @return
	 */
	@PostMapping(path = "/employee/removepto/", produces = "application/json", consumes = "application/json")
	public ResponseBean removeEmployeeTimeOff(@RequestBody EmployeePto removePto)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{
			String report = this.pubEmpService.removeEmployeeTimeOff(removePto);

			if (report.equals("Success"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("PTO details has been successfully removed");
				respBean.setResult(null);
			}

			else if (report.equals("UnSuccess"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("PTO details has not been remove !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	/**
	 * To List The PTO Details Based on the Particular EmpId
	 * 
	 * @param empId
	 * @return
	 */
	@GetMapping(path = "/employee/ptolist/{id}", produces = "application/json")
	public ResponseBean EmployeeTimeOffList(@PathVariable("id") String empId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{
			EmployeePto ptoList = this.pubEmpService.EmployeeTimeOffList(empId);

			if ((ptoList != null))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(ptoList);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No data found !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	/**
	 * 
	 * List Of Services of Particular Employee Based On EmpId
	 * 
	 * @param empId
	 * @return
	 */
	@GetMapping(value = "/employee/servicelist/{id}", produces = "application/json")
	public ResponseBean publisherBusinessServiceListByEmpId(@PathVariable("id") String empId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{
			List<Services> result = this.pubEmpService.publisherBusinessServiceListByEmpId(empId);

			if ((result != null) && !(result.isEmpty()))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No data found !");
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@PutMapping(path = "/updateappointmentstatus", consumes = "application/json")
	public ResponseBean updateAppointmentStatus(@RequestBody AppointmentCalendar updateStatus)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			String report = this.pubEmpService.updateStatus(updateStatus);

			if (report.equals("INVALID"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid Data ! | appointment status  has not been  updated");
				respBean.setResult(null);

			}
			else if (report.equalsIgnoreCase("UNABLE"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Sorry! unable to make it as performed");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Appointment status  has been successfully updated");
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	/**
	 * To list the all appointments in a particular date and PublisherId
	 * 
	 * @param AppointmentCalendar
	 *            object
	 * 
	 * @return To list the all appointments in a particular date and PublisherId
	 */
	@PostMapping(path = "/getappointmentconsumer/", produces = "application/json", consumes = "application/json")
	public ResponseBean listOfServicesBasedAppointmentByDate(@RequestBody AppointmentBean appCla)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			Object report = this.pubEmpService.listOfServicesBasedAppointmentByDate(appCla);

			if (report.equals("Holiday"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Today  is holiday");
				respBean.setResult(null);
			}

			else if (report.equals("INVALID_BUSINESS"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid business !");
				respBean.setResult(null);
			}

			else if (report.equals("No_Employee_Found"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("No employee available !");
				respBean.setResult(null);
			}

			else if (report.equals("DETAILS_REQUIRED"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Details required !");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(report);
			}

		}
		catch (Exception e)
		{

			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@GetMapping(path = "/consumerappoinmentlist/{id}", produces = "application/json")
	public ResponseBean consumerAppoinmentList(@PathVariable("id") String macId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			List<AppointmentCalendar> app = this.pubEmpService.consumerAppoinmentList(macId);

			if (app == null)
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(app);
			}

			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Consumer appoinment list");
				respBean.setResult(app);

			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

	@PostMapping(path = "employee/iconsave", consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
	        produces = "application/json")

	public ResponseBean iconSave(@RequestParam("file") MultipartFile file, @RequestParam("id") String empId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			PublisherBusinessEmployee pBEmp = new PublisherBusinessEmployee();
			String path = null;

			String image = this.pubEmpService.getIcon(empId);

			if (!(image.equals("")))
			{

				String ext = FilenameUtils.getExtension(image);

				String filePath = empId + "." + ext;

				File oldFile = new File(this.dir + File.separator + filePath);
              boolean x=oldFile.delete();
              x=true;
				if (x)
				{

					File f = new File(this.dir + File.separator + empId + "."
					        + FilenameUtils.getExtension(file.getOriginalFilename()));
					file.transferTo(f);

					path = this.url + empId + "." + FilenameUtils.getExtension(file.getOriginalFilename());

					pBEmp.setIcon(path);
					pBEmp.setId(empId);
				}
			}
			else if ((image.equals("INVALID")))
			{

				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Image has not been uploaded !");
				respBean.setResult(null);

			}

			else
			{
				File f = new File(this.dir + File.separator + empId + "."
				        + FilenameUtils.getExtension(file.getOriginalFilename()));
				file.transferTo(f);

				path = this.url + empId + "." + FilenameUtils.getExtension(file.getOriginalFilename());

				pBEmp.setIcon(path);
				pBEmp.setId(empId);
			}

			String report = this.pubEmpService.saveIcon(pBEmp);

			if (report.equals("UNSUCCESS"))
			{

				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Image has not been uploaded !");
				respBean.setResult(null);

			}
			else
			{

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Image has been successfully uploaded ");
				respBean.setResult(path);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@GetMapping(value = "employee/geticon/{id}")
	public void getIcon(HttpServletRequest request, HttpServletResponse response, @PathVariable("id") String empId)
	{

		try
		{

			logger.info("empId" + empId);

			String imagePath = this.pubEmpService.getIcon(empId);

			if (!(imagePath.equals("")))
			{

				// logger.info("REport ----" + report);

				String ext = FilenameUtils.getExtension(imagePath);

				// logger.info("exrtt ----" + ext);

				String filePath = empId + "." + ext;

				// logger.info("filePath ----" + filePath);

				String path = this.dir + File.separator + filePath;
				File file = new File(path);

				if (file.exists())
				{

					String mimeType = URLConnection.guessContentTypeFromName(file.getName());
					if (mimeType == null)
					{
						mimeType = "application/octet-stream";
					}

					response.setContentType(mimeType);

					response.setHeader("Content-Disposition",
					        String.format("inline; filename=\"" + file.getName() + "\""));

					response.setContentLength((int) file.length());

					InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

					FileCopyUtils.copy(inputStream, response.getOutputStream());

				}

			}

		}
		catch (Exception e)
		{

			e.printStackTrace();
		}

	}

	// This service is not used now,

	/**
	 * To Add PTO Details To Particular Employee
	 * 
	 * @param pto
	 * @return
	 */
	@PostMapping(path = "/employee/addpto/", produces = "application/json", consumes = "application/json")
	public ResponseBean addEmployeeTimeOff(@RequestBody AddPto pto)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			String report = this.pubEmpService.addEmployeeTimeOff(pto);

			if (report.equals("SUCCESS"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("PTO details has been successfully added");
				respBean.setResult(null);
			}
			else if (report.equals("UNSUCCESS"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("PTO details has not been  added");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

}
