package com.businessApp.service;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import com.businessApp.bean.ConsumerScannnedBusinesses;
import com.businessApp.bean.Device;
import com.businessApp.bean.LoginResult;
import com.businessApp.bean.SaveConsumerBusinessDetails;
import com.businessApp.bean.UserBean;
import com.businessApp.model.ConsumerBusinessDetails;
import com.businessApp.model.CountriesList;
import com.businessApp.model.Messages;
import com.businessApp.model.PlansDetails;
import com.businessApp.model.PublisherBusiness;
import com.businessApp.model.PublisherBusinessEmployee;
import com.businessApp.model.ServiceCategory;
import com.businessApp.model.TrackReport;
import com.businessApp.model.User;
import com.businessApp.model.UserLoginDevices;
import com.businessApp.model.UserSubscriptions;
import com.businessApp.repositories.ConsumerBusinessDetailsRepository;
import com.businessApp.repositories.UserRepository;
import com.businessApp.util.EncryptUtil;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mongodb.WriteResult;

@Service
public class UserService
{

	private static Logger logger = LoggerFactory.getLogger(UserService.class);

	@Autowired
	UserRepository userRepo;

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	LoginResult loginResult;

	@Autowired
	Device device;

	@Autowired
	ConsumerBusinessDetailsRepository consumerBusiness;

	@Autowired
	PublisherService publisherService;

	@Autowired
	SubscriptionService subService;

	@Autowired
	UserBean userBean;

	@Autowired
	User user;

	@Autowired
	PublisherBusinessEmployeeService pBEmpService;
	@Autowired
	UserLoginDevices userLoginDevices;

	@Autowired
	TrackReport trackReport;

	public void save(User user) throws Exception
	{
		this.userRepo.save(user);
	}

	public Object publisherList(String type) throws Exception
	{

		int typeValue = Integer.parseInt(type);

		if ((typeValue == 1) || (typeValue == 2) || (typeValue == 3))
		{
			return this.userRepo.listUser(typeValue);
		}
		else
		{
			return "INVALID_TYPE";
		}

	}

	public Object updateUser(User user) throws Exception
	{

		if (user.getId() != null)
		{
			Query query = new Query();
			query.addCriteria(Criteria.where("id").is(user.getId()));
			Update update = new Update();
			if ((user.getName() != null) && !(user.getName().isEmpty()))
			{
				update.set("name", user.getName());
			}

			if (user.getCity() != null)
			{
				update.set("city", user.getCity());
			}

			if (user.getState() != null)
			{
				update.set("state", user.getState());
			}

			if (user.getCountry() != null)
			{
				update.set("country", user.getCountry());
			}

			if (user.getZip() != null)
			{
				update.set("zip", user.getZip());
			}

			if (user.getAddress1() != null)
			{
				update.set("address1", user.getAddress1());
			}

			if (user.getAddress2() != null)
			{
				update.set("address2", user.getAddress2());
			}

			if (user.getOtp() != null)
			{
				update.set("otp", user.getOtp());
			}

			// For Consumer Token Update Only
			if ((user.getToken() != null) && !(user.getToken().isEmpty()))
			{
				update.set("token", user.getToken());
			}

			if ((user.getActivation() != 0))
			{
				update.set("activation", user.getActivation());
			}

			if (user.getModifiedTime() != null)
			{
				update.set("modifiedTime", user.getModifiedTime());
			}
			query.fields().exclude("phone");
			query.fields().exclude("email");
			query.fields().exclude("password");

			User userData = this.mongoTemplate.findAndModify(query, update, User.class);

			if (userData != null)
			{
				return userData;
			}
			else
			{
				return null;
			}

		}
		else
		{
			return "ID_REQ";

		}

	}

	/**
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> toSaveUser(User user) throws Exception
	{

		Map<String, String> userData = new HashMap<>();

		if ((user.getPhone() != null))
		{
			boolean loginType = phoneValidator(user.getPhone());

			if (loginType)
			{
				User phoneExist = userExist(user.getPhone());

				if ((phoneExist != null))
				{

					userData.put("id", phoneExist.getId());
					userData.put("message", "Phone_Exist");
					userData.put("active", Integer.toString(phoneExist.getActivation()));
					userData.put("type", Integer.toString(phoneExist.getType()));
					
					return userData;
					
				}
				else{
					
				
				userData = saveUser(user);
				return userData;
				}
				/*boolean emailValid = emailValidator(user.getUserId());
				if ((emailValid != true))
				{
					userData.put("message", "INVALID_Email");

					return userData;
				}*/

			/*	else
				{
					User emaiExist = emailExist(user);

					if ((emaiExist != null))
					{
						userData.put("id", emaiExist.getId());
						userData.put("message", "Email_Exist");
						userData.put("active", Integer.toString(emaiExist.getActivation()));
						userData.put("type", Integer.toString(emaiExist.getType()));
					}

					else
					{
						userData = saveUser(user);
					}

					return userData;
				}*/

			}

			else
			{
				boolean phoneValid = phoneValidator(user.getPhone());

				if ((phoneValid != true))
				{
					userData.put("message", "INVALID_MOBILE");
					return userData;

				}

				else
				{

					User phoneExist = userExist(user.getPhone());

					if ((phoneExist != null))
					{

						userData.put("id", phoneExist.getId());
						userData.put("message", "Phone_Exist");
						userData.put("active", Integer.toString(phoneExist.getActivation()));
						userData.put("type", Integer.toString(phoneExist.getType()));
					}

					else
					{
						userData = saveUser(user);
					}

					return userData;

				}
			}

		}

		else
		{

			userData.put("message", "EmailOrPhoneRequired");

			return userData;

		}

	}

	public User userExist(String userID)
	{
		User emailExist =null;
       try
       {
    	   Query query = new Query();
   		query.addCriteria(Criteria.where("phone").is(userID));
   		query.fields().include("userId");
   		query.fields().include("activation");
   		query.fields().include("type");
   		query.fields().include("emailOTP");
   		query.fields().include("phoneOTP");
   		query.fields().include("otp");
   		query.fields().include("phone");
   		query.fields().include("countryCode");

   		emailExist =this.mongoTemplate.findOne(query, User.class);
    	   
       }
       catch(Exception ex)
       {
    	   ex.printStackTrace();
       }
		
		return emailExist;
	}

	public User emailExist(User user)
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(user.getEmail()));
		query.fields().include("email");
		query.fields().include("activation");

		User emailExist = this.mongoTemplate.findOne(query, User.class);
		return emailExist;
	}

	public User phonelExist(User user)
	{
		Query query2 = new Query();
		query2.addCriteria(Criteria.where("phone").is(user.getPhone()));
		query2.fields().include("phone");
		query2.fields().include("activation");
		User phonelExist = this.mongoTemplate.findOne(query2, User.class);
		return phonelExist;
	}

	public User getUserById(String phone) throws Exception
	{

		Query listQry = new Query();

		listQry.addCriteria(Criteria.where("id").is(phone).andOperator(Criteria.where("status").is(0)));
	     listQry.fields().include("id");
		 listQry.fields().include("name");
		 listQry.fields().include("type");
		 listQry.fields().include("address1");
		 listQry.fields().include("address2");
		 listQry.fields().include("city");
		 listQry.fields().include("state");
		 listQry.fields().include("country");
		 listQry.fields().include("zip");
		 listQry.fields().include("otp");
		 listQry.fields().include("phone");
		 listQry.fields().include("email");
		 listQry.fields().include("modifiedBy");
		 listQry.fields().include("modifiedTime");
		 listQry.fields().include("icon");
		 listQry.fields().include("token");
		 listQry.fields().include("deviceID");
		
		long count = this.mongoTemplate.count(listQry, User.class);

		if (count > 0)
		{

			return this.mongoTemplate.findOne(listQry, User.class);
		}
		else
		{
			return null;
		}

	}

	// ------------Login -----------------------

	public String loginUserWithId(UserBean user) throws Exception
	{ 
		User userDetails = null;

		String	mobileOTPResult = null;
		Query loginqry=new Query();
		loginqry.addCriteria(Criteria.where("phone").is(user.getPhonenumber()));

		userDetails = this.mongoTemplate.findOne(loginqry, User.class);
			
						
		if(userDetails != null)
		{
			
			char[] otp = generateOTP(5);

			String otpStr = new String(otp);
			
			//for updating and generating otp for login
			Update update = new Update();
			
			update.set("otp", otpStr);
			this.mongoTemplate.findAndModify(loginqry, update, User.class);
			
			// send mobile OTP
		   mobileOTPResult = mobileOTPService(otpStr, userDetails.getPhone());
		    
			return "Success";
		}
		
		return "LOGIN FAILED";
		
		}
	
	public String resendOtp(UserBean user) throws Exception
	{ 
		User userDetails = null;

		String	mobileOTPResult = null;
		Query loginqry=new Query();
		loginqry.addCriteria(Criteria.where("phone").is(user.getPhonenumber()));

		userDetails = this.mongoTemplate.findOne(loginqry, User.class);
			
						
		if(userDetails != null)
		{
			
			/*char[] otp = generateOTP(5);

			String otpStr = new String(otp);
			
			//for updating and generating otp for login
			Update update = new Update();
			
			update.set("otp", otpStr);
			this.mongoTemplate.findAndModify(loginqry, update, User.class);*/
			
			
			Query otpqry=new Query();
			otpqry.addCriteria(Criteria.where("phone").is(user.getPhonenumber()));
			
			userDetails = this.mongoTemplate.findOne(loginqry, User.class);
			
			String otpStr = userDetails.getOtp();
			// send mobile OTP
		   mobileOTPResult = mobileOTPService(otpStr, userDetails.getPhone());
		    
			return "Success";
		}
		
		return "FAILED";
		
		}

	public boolean emailValidator(String email)
	{

		try
		{

			String emailregex = "^[A-Za-z][A-Za-z0-9!@#$.%^&*]*$";
			Boolean b = email.matches(emailregex);

			if (b == false)
			{
				return false;
			}
			else if (b == true)
			{
				return true;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();

		}
		return false;
	}

	public boolean phoneValidator(String phoneNo)
	{
		if (phoneNo.matches("\\d{10}"))
		{
			return true;
		}
		else if (phoneNo.matches("\\d{3}[-\\.\\s]\\d{3}[-\\.\\s]\\d{4}"))
		{
			return true;
		}
		else if (phoneNo.matches("\\d{3}-\\d{3}-\\d{4}\\s(x|(ext))\\d{3,5}"))
		{
			return true;
		}
		else if (phoneNo.matches("\\(\\d{3}\\)-\\d{3}-\\d{4}"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public String toFindLogInType(String loginId)
	{
		String pattern = "\\d{10}|(?:\\d{3}-){2}\\d{4}|\\(\\d{3}\\)\\d{3}-?\\d{4}";

		if (loginId.matches(pattern))
		{
			return "phone";
		}

		else
		{
			return "email";
		}

	}

	public User getUserDetails()
	{

		return this.loginResult.getUserData();
	}

	public String loginUser(UserBean user) throws Exception
	{

		int userType = user.getType();
		User userDetails = null;
		Query query = new Query();

		query.addCriteria(Criteria.where("type").is(userType).and("status").is(0)
		        .andOperator(Criteria.where("userId").is(user.getId())));

		userDetails = this.mongoTemplate.findOne(query, User.class);

		if (userDetails != null)
		{
			this.loginResult.setUserData(userDetails);
			String mobileOTPResult = null, EmailOTPResult = null;

			if (userDetails.getActivation() == 0)
			{

				// generate otp string
				char[] otp = generateOTP(5);
				String otpStr = new String(otp);
				userDetails.setOtp(otpStr);
				userDetails.setModifiedTime(new java.util.Date());

				if (userDetails.getPhoneOTP() != null)
				{
					String phoneNumber = userDetails.getCountryCode() + userDetails.getPhoneOTP();
					mobileOTPResult = mobileOTPService(otpStr, phoneNumber);
				}
				if (userDetails.getEmailOTP() != null)
				{
					EmailOTPResult = SendEmailOTP(otpStr, userDetails.getEmailOTP());
				}

				if (((mobileOTPResult.equalsIgnoreCase("Success")) || (mobileOTPResult.equalsIgnoreCase("OK"))
				        || (EmailOTPResult.equalsIgnoreCase("Success"))))
				{
					Query queryt = new Query();
					queryt.addCriteria(Criteria.where("id").is(userDetails.getId()));
					Update update = new Update();

					if ((userDetails.getOtp() != null) && (otpStr.length() == 5))
					{
						update.set("otp", userDetails.getOtp());
					}

					// setting OTP expire time
					Calendar time = Calendar.getInstance();
					time.setTime(new java.util.Date());

					time.add(Calendar.MINUTE, 10);

					update.set("otpExpireTime", time.getTime());

					if (userDetails.getModifiedTime() != null)
					{
						update.set("modifiedTime", userDetails.getModifiedTime());
					}

					this.mongoTemplate.findAndModify(query, update, User.class);
				}
			}

			else if (userDetails.getActivation() == 1 || userDetails.getActivation() == 2)
			{

				Date currentTime = new Date();

				Date otpExpTime = userDetails.getOtpExpireTime();

				if (currentTime.compareTo(otpExpTime) > 0)
				{

					// generate otp string
					char[] otp = generateOTP(5);
					String otpStr = new String(otp);
					userDetails.setOtp(otpStr);
					userDetails.setModifiedTime(new java.util.Date());

					// previous OTP has been expired
					if (userDetails.getPhoneOTP() != null)
					{
						String phoneNumber = userDetails.getCountryCode() + userDetails.getPhoneOTP();
						mobileOTPResult = mobileOTPService(otpStr, phoneNumber);
					}
					if (userDetails.getEmailOTP() != null)
					{
						EmailOTPResult = SendEmailOTP(otpStr, userDetails.getEmailOTP());
					}

					if (((mobileOTPResult.equalsIgnoreCase("Success")) || (mobileOTPResult.equalsIgnoreCase("OK"))
					        || (EmailOTPResult.equalsIgnoreCase("Success"))))
					{
						Query queryt = new Query();
						queryt.addCriteria(Criteria.where("id").is(userDetails.getId()));
						Update update = new Update();

						if ((userDetails.getOtp() != null) && (otpStr.length() == 5))
						{
							update.set("otp", userDetails.getOtp());
						}

						// setting OTP expire time
						Calendar time = Calendar.getInstance();
						time.setTime(new java.util.Date());

						time.add(Calendar.MINUTE, 10);

						update.set("otpExpireTime", time.getTime());

						if (userDetails.getModifiedTime() != null)
						{
							update.set("modifiedTime", userDetails.getModifiedTime());
						}

						this.mongoTemplate.findAndModify(query, update, User.class);
					}
				}
				else
				{
					// previous OTP has not been expired
					if (userDetails.getPhoneOTP() != null)
					{
						String phoneNumber = userDetails.getCountryCode() + userDetails.getPhoneOTP();
						mobileOTPResult = mobileOTPService(userDetails.getOtp(), phoneNumber);
					}
					if (userDetails.getEmailOTP() != null)
					{
						EmailOTPResult = SendEmailOTP(userDetails.getOtp(), userDetails.getEmailOTP());
					}

				}
			}

			this.loginResult.setUserData(userDetails);

			if (userType == 2)
			{
				this.loginResult.setBusinessData(this.publisherService.businessListBypublisherId(userDetails.getId()));

				this.loginResult.setMenuData(this.subService.menuList());

			}
			else
			{
				this.loginResult.setBusinessData(null);
				this.loginResult.setMenuData(null);
			}
			return "Success";

		}

		else
		{

			return "InvalidUser";
		}
	}

	private String SendEmailOTP(String otp, String email)
	{

		return "Success";
	}

	public String deleteUserById(String userId) throws Exception
	{

				Query query = new Query();
				query.addCriteria(Criteria.where("id").is(userId));
//				Update upd = new Update();
//				upd.set("status", 1);
				WriteResult userDataResult = this.mongoTemplate.remove(query, User.class);

				if (userDataResult.getN() > 0)
				{
					return "SUCCESS";
				}

				else
				{
					return "UNSUCCESS";
				}
			}
			

	

	public Map<String, String> insertConsumerDeviceId(ConsumerBusinessDetails consumerBusin) throws Exception
	{
		Random rand = new Random(); 
		 ObjectId obj=new ObjectId(new Date(), rand.nextInt(1000)); 
		 consumerBusin.setId(obj.toString());
		
		Map<String, String> tmp = new HashMap<>();
		if (consumerBusin.getMacId() != null)
		{

			ConsumerBusinessDetails conBusData = getConsumerBusinessDetails(consumerBusin.getMacId());

			if (conBusData == null)
			{
				Date dt = new Date();

				if (consumerBusin.getCreatedTime() == null)
				{

					consumerBusin.setCreatedTime(dt);
					consumerBusin.setModifiedTime(dt);

				}

				this.consumerBusiness.save(consumerBusin);

				// Save the consumer details in User Table
				this.user.setId(consumerBusin.getId());
				this.user.setType(3);
				this.user.setToken("");
				this.user.setDeviceID(consumerBusin.getMacId());
				this.user.setCreatedTime(dt);
				this.user.setModifiedTime(dt);
				this.userRepo.save(this.user);

				tmp.put("id", consumerBusin.getId());
				tmp.put("message", "SUCCESS");
				return tmp;

			}

			else
			{

				tmp.put("id", conBusData.getId());
				tmp.put("message", "EXIST");
				return tmp;
			}

			// Previous Requirement
			// else
			// {
			// ConsumerScannnedBusinesses consumer = getComsumerBusinessList(conBusData);
			// return consumer;
			// }

		}
		else
		{

			tmp.put("message", "DEVID_REQ");
			return tmp;
		}

	}

	public Object saveConsumerBusinessDetails(SaveConsumerBusinessDetails consumerBusiness)
	{

		String s;
		
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(consumerBusiness.getId())
		        .andOperator(Criteria.where("macId").is(consumerBusiness.getMacId())));

		Update update = new Update();
		update.set("modifiedTime", consumerBusiness.getModifiedTime());

		update.addToSet("businesses", consumerBusiness.getbId());

		ConsumerBusinessDetails add = this.mongoTemplate.findAndModify(query, update, ConsumerBusinessDetails.class);

		if (add != null)
		{
			s = "SUCCESS";
		}
		else
		{
			s = "UNSUCCESS";
		}

		return s;

	}

	public Object consumerBusinessList(String macId) throws Exception

	{

		ConsumerBusinessDetails tmp = getConsumerBusinessDetails(macId);

		if (tmp != null)
		{

			return getComsumerBusinessList(tmp);
		}

		else
		{
			return "INVALID";
		}

	}

	private ConsumerScannnedBusinesses getComsumerBusinessList(ConsumerBusinessDetails tmp) throws Exception
	{
		ConsumerScannnedBusinesses consumer = new ConsumerScannnedBusinesses();
		List<PublisherBusiness> pB = new ArrayList<>();

		consumer.setId(tmp.getId());
		consumer.setMacId(tmp.getMacId());

		if ((tmp.getBusinesses() != null) && !(tmp.getBusinesses()).isEmpty())
		{

			for (int i = 0; i < tmp.getBusinesses().size(); i++)
			{

				PublisherBusiness pBData = this.publisherService.getPublisherBusinessData(tmp.getBusinesses().get(i));

				// to check weather the business has services or not

				List<ServiceCategory> newServCat = new ArrayList<>();

				if (pBData != null)
				{
					if (pBData.getServiceCategory() != null)
					{
						for (int j = 0; j < pBData.getServiceCategory().size(); j++)
						{
							if (pBData.getServiceCategory().get(j) != null)
							{
								int flag = 0;
								List<Integer> servIndexes = new ArrayList<>();

								if (pBData.getServiceCategory().get(j).getService() != null)
								{
									for (int k = 0; k < pBData.getServiceCategory().get(j).getService().size(); k++)
									{

										List<PublisherBusinessEmployee> employees = this.empOfParticularService(pBData,
										        pBData.getServiceCategory().get(j).getService().get(k).getId());

										if (employees != null && employees.size() > 0)
										{
											flag = 1;
										}
										else
										{
											servIndexes.add(k);

										}
									}

								}

								if (flag == 1)
								{

									if (servIndexes != null && servIndexes.size() > 0)
									{
										for (int index = servIndexes.size() - 1; index >= 0; index--)
										{
											pBData.getServiceCategory().get(j).getService()
											        .remove(servIndexes.get(index).intValue());
										}
									}

									newServCat.add(pBData.getServiceCategory().get(j));
								}
							}
						}
					}
				}

				pBData.setServiceCategory(newServCat);

				if (pBData.getServiceCategory() != null && pBData.getServiceCategory().size() > 0)
				{
					pB.add(pBData);
				}

			}

			if (pB.size() > 0)
			{
				consumer.setBusinesses(pB);
			}

		}

		return consumer;
	}

	private List<PublisherBusinessEmployee> empOfParticularService(PublisherBusiness pBData, String serviceId)
	        throws Exception
	{
		List<PublisherBusinessEmployee> empList = this.pBEmpService.employeeList(pBData.getId(),
		        pBData.getPublisherId());

		List<PublisherBusinessEmployee> finalEmpList = new ArrayList<>();

		if (empList != null)
		{
			for (int i = 0; i < empList.size(); i++)
			{
				if (empList.get(i).getServiceCategory() != null)
				{
					for (int j = 0; j < empList.get(i).getServiceCategory().size(); j++)
					{
						if (empList.get(i).getServiceCategory().get(j).getService() != null)
						{
							for (int k = 0; k < empList.get(i).getServiceCategory().get(j).getService().size(); k++)
							{
								if (empList.get(i).getServiceCategory().get(j).getService().get(k).getId()
								        .equals(serviceId))
								{
									finalEmpList.add(empList.get(i));
								}
							}
						}
					}
				}
			}
		}

		return finalEmpList;
	}

	public ConsumerBusinessDetails getConsumerBusinessDetails(String deviceID)
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("macId").is(deviceID));

		return this.mongoTemplate.findOne(query, ConsumerBusinessDetails.class);
	}

	public CountriesList countriesList()
	{

		Query query = new Query();
		CountriesList countriesData = this.mongoTemplate.findOne(query, CountriesList.class);
		return countriesData;
	}

	public String saveIcon(User user)
	{
		if (user != null)
		{
			Query updQry = new Query(Criteria.where("id").is(user.getId()));
			Update upd = new Update();

			if (user.getIcon() != null)
			{
				upd.set("icon", user.getIcon());
			}

			if (user.getModifiedTime() == null)
			{
				Date date = new Date();

				upd.set("modifiedTime", date);
			}

			this.mongoTemplate.upsert(updQry, upd, User.class);

			return "SUCCESS";

		}

		else
		{

			return "UNSUCCESS";
		}
	}

	public String getIcon(String userId) throws Exception
	{
		User userData = getUserById(userId);
		if (userData != null)
		{
			return userData.getIcon();
		}

		else
		{
			return "INVALID";
		}
	}

	public String removeConsumerBusiness(SaveConsumerBusinessDetails cBD)
	{

		Query query1 = new Query();

		if (cBD.getMacId() != null)
		{
			query1.addCriteria(Criteria.where("businesses").in(cBD.getbId())
			        .andOperator(Criteria.where("macId").is(cBD.getMacId())));
		}

		else
		{
			query1.addCriteria(Criteria.where("businesses").in(cBD.getbId()));
		}

		List<ConsumerBusinessDetails> listOfConsumerBusiness = this.mongoTemplate.find(query1,
		        ConsumerBusinessDetails.class);

		if (listOfConsumerBusiness.size() > 0)
		{
			for (int i = 0; i < listOfConsumerBusiness.size(); i++)
			{

				Query query2 = new Query();
				query2.addCriteria(Criteria.where("id").is(listOfConsumerBusiness.get(i).getId()));
				Update upd = new Update();
				upd.pull("businesses", cBD.getbId());

				this.mongoTemplate.updateFirst(query2, upd, ConsumerBusinessDetails.class);

			}

			return "SUCCESS";
		}

		else
		{

			return "UNSUCCESS";
		}

	}

	public Object saveOTPDetails(User saveOTP) throws Exception
	{

		if (saveOTP.getId() != null)
		{
			Query query = new Query();
			query.addCriteria(Criteria.where("id").is(saveOTP.getId()));

			Update update = new Update();

			if (saveOTP.getType() == 2)
			{
				// Generate OTP

				char[] otp = generateOTP(5);

				String otpStr = new String(otp);
				saveOTP.setOtp(otpStr);

				if (saveOTP.getPhoneOTP() != null)
				{
					update.set("phoneOTP", saveOTP.getPhoneOTP());
					update.set("countryCode", saveOTP.getCountryCode());

					String phoneNumber = saveOTP.getCountryCode() + saveOTP.getPhoneOTP();
					// send mobile OTP
					mobileOTPService(otpStr, phoneNumber);
				}

				if (saveOTP.getEmailOTP() != null)
				{
					update.set("emailOTP", saveOTP.getEmailOTP());
					// emailOTPService();
				}

				if ((saveOTP.getOtp() != null) && (otpStr.length() == 5))
				{
					update.set("otp", saveOTP.getOtp());

				}

			}

			if (saveOTP.getModifiedTime() != null)
			{
				update.set("modifiedTime", saveOTP.getModifiedTime());
			}

			this.mongoTemplate.findAndModify(query, update, User.class);

			this.userBean.setId(saveOTP.getId());
			this.userBean.setType(saveOTP.getType());
			this.userBean.setOtp(saveOTP.getOtp());

			return this.userBean;

		}
		else
		{
			return null;

		}
	}

	private String mobileOTPService(String otp, String mobile)
	        throws MalformedURLException, IOException, UnirestException
	{

		String uriComponents = UriComponentsBuilder.newInstance().scheme("http").host("2factor.in")
		        .path("/API/V1/917492e3-bbfb-11e8-a895-0200cd936042/SMS/{phone_number}/{otp}/BMLOGIN").build()
		        .expand(mobile, otp).encode().toUriString();

		com.mashape.unirest.http.HttpResponse<String> response = Unirest.get(uriComponents)
		        .header("content-type", "application/x-www-form-urlencoded").asString();

		return response.getStatusText();
	}

	public char[] generateOTP(int len)
	{

		String numbers = "123456789";

		Random rndm_method = new Random();

		char[] otp = new char[len];

		for (int i = 0; i < len; i++)
		{

			otp[i] = numbers.charAt(rndm_method.nextInt(numbers.length()));
		}
		return otp;
	}

	public Object verifyOTP(User user) throws Exception
	{
		User userData = getUserById(user.getPhone());

		if (userData != null)
		{
			HashMap<String, String> userDetails = new HashMap<String, String>();

			if (userData.getOtp().equals(user.getOtp()))
			{
				// for check the user having Businesses
				List<Object> pBusinessData = this.publisherService.businessListBypublisherId(userData.getId());
				if (pBusinessData.size() > 0)
				{
					userData.setBusinessData(true);
				}

				if (userData.getActivation() == 0)
				{
					userData.setActivation(1);
					user.setId(user.getId());
					user.setActivation(1);

					// Update User
					this.updateUser(user);
				}
				if (userData.getType() == 2 && userData.getActivation() == 2)
				{

					// -----Add Device Id Here ---------------
					String result = this.addDeviceIdToLoginDevices(user.getId(), user.getDeviceID(), user.getOsType());

					user.setId(userData.getId());
					user.setDeviceID(userData.getDeviceID());

					HashMap<String, String> tokenDetails = this.getToken(user);

					if (tokenDetails.get("token") != null)
					{
						userData.setToken(tokenDetails.get("token"));
					}
					else
					{

						userData.setToken(" ");
					}

					if (result.equalsIgnoreCase("FAIL"))
					{
						return "UNABLE";
					}

				}

				userDetails.put("id", userData.getId());
				userDetails.put("activation", Integer.toString(userData.getActivation()));
				userDetails.put("token", userData.getToken());
				userDetails.put("businessData", Boolean.toString(userData.isBusinessData()));

				// return userData;

				return userDetails;
			}
			else
			{
				return "INVALID_OTP";
			}
		}
		else
		{
			return "INVALID";
		}

	}

	public int chekcUserActive(String id)
	{

		int code = 200;
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id).andOperator(Criteria.where("active").is(1)));

		User userData = this.mongoTemplate.findOne(query, User.class);

		if (userData != null)
		{
			logger.info("userwrw ----" + userData.getId());
			code = 204;
		}

		return code;
	}

	public Map<String, String> saveUser(User user) throws Exception
	{
		Map<String, String> userData = new HashMap<>();
		String mobileOTPResult = null, EmailOTPResult = null;

		 Random rand = new Random(); 
		 ObjectId obj=new ObjectId(new Date(), rand.nextInt(1000)); 
		 user.setId(obj.toString());
		 
		if (user.getPassword() != null)
		{

			user.setPassword(EncryptUtil.encrypt(user.getPassword()));
		}

		// Generate OTP

		char[] otp = generateOTP(5);

		String otpStr = new String(otp);

		// setting OTP expire time
		Calendar time = Calendar.getInstance();
		time.setTime(new java.util.Date());

		time.add(Calendar.MINUTE, 10);

		user.setOtpExpireTime(time.getTime());

		if ((user.getPhoneOTP() != null) && (user.getCountryCode() != null))
		{
			String phoneNumber = /*user.getCountryCode() + */ user.getPhone();
			// send mobile OTP
			mobileOTPResult = mobileOTPService(otpStr, phoneNumber);
		}

		if (user.getEmailOTP() != null)
		{

			EmailOTPResult = SendEmailOTP(otpStr, user.getEmailOTP());
		}

		if ((mobileOTPResult.equalsIgnoreCase("Success")) || (mobileOTPResult.equalsIgnoreCase("OK"))
		        || (EmailOTPResult.equalsIgnoreCase("Success")))
		{
			user.setOtp(otpStr);
		}

		this.mongoTemplate.save(user);

		// Tracking Start for User Object
		this.trackReport.setId(user.getId());
		this.trackReport.setCreatedTime(user.getCreatedTime());
		this.trackReport.setRequest(user);
		this.mongoTemplate.save(this.trackReport);
		// Tracking Close

		// To store devices start
		List<Device> devices = new ArrayList<>();

		ObjectId id = new ObjectId();
		userLoginDevices.setId(id.toString());
		userLoginDevices.setUserId(user.getId());
		userLoginDevices.setDevices(devices);
		userLoginDevices.setCreatedTime(user.getCreatedTime());
		this.mongoTemplate.save(userLoginDevices);
		// To store devices end

		// Tracking Start to store devices start
		this.trackReport.setId(id.toString());
		this.trackReport.setCreatedTime(user.getCreatedTime());
		this.trackReport.setRequest(userLoginDevices);
		this.mongoTemplate.save(this.trackReport);
		// Tracking Close

		userData.put("id", user.getId());
		userData.put("message", "SUCCESS");
		userData.put("otp", user.getOtp());
		userData.put("type", Integer.toString(user.getType()));
		userData.put("trackId", user.getId());

		return userData;
	}

	public boolean userAvailable(User user)
	{
		boolean status;
		User userData = userExist(user.getPhone());

		if (userData != null)
		{
			status = true;
		}
		else
		{
			status = false;
		}

		return status;
	}

	public List<Messages> listOfMessagesByConsumerId(String conId)
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("receiverID").is(conId.toString()));
		query.with(new Sort(new Order(Direction.DESC, "createdTime")));
		return this.mongoTemplate.find(query, Messages.class);
	}

	public Object removeMessage(String id)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id));
		Messages msg = this.mongoTemplate.findAndRemove(query, Messages.class);
		if (msg != null)
		{
			return "SUCCESS";
		}
		else
		{
			return "UNSUCCESS";
		}

	}

	public String logoutFromDevice(User logoutData) throws Exception
	{
		String result = null;

		if (logoutData != null)
		{
			if (logoutData.getType() != 2)
			{
				result = "INVALID_TYPE";
			}
			else
			{
				if (this.getUserById(logoutData.getId()) != null)
				{
					Query query = new Query();
					query.addCriteria(Criteria.where("userId").is(logoutData.getId()));

					UserLoginDevices deviceData = this.mongoTemplate.findOne(query, UserLoginDevices.class);

					if (deviceData != null)
					{
						if (deviceData.getDevices() != null && deviceData.getDevices().size() > 0)
						{
							for (int i = 0; i < deviceData.getDevices().size(); i++)
							{
								if (deviceData.getDevices().get(i).getDeviceID().equals(logoutData.getDeviceID()))
								{

									Update update = new Update();
									update.pull("devices", deviceData.getDevices().get(i));

									this.mongoTemplate.upsert(query, update, UserLoginDevices.class);

									result = "SUCCESS";

								}
							}
						}

					}
					else
					{
						result = "INVALID";
					}

				}
				else
				{
					result = "INVALID";
				}
			}
		}
		else
		{
			result = "INVALID";
		}

		return result;

	}

	public String addDeviceIdToLoginDevices(String userId, String deviceID, String osType)
	{
		String result = null;

		UserLoginDevices userLoginDevicesData = getDeviceDetails(userId);

		if (userLoginDevicesData != null)
		{
			Query query2 = new Query();
			query2.addCriteria(Criteria.where("uId").is(userId));

			UserSubscriptions userSub = this.mongoTemplate.findOne(query2, UserSubscriptions.class);

			int allowedDevices = 0;
			if (userSub != null)
			{
				Query query3 = new Query();
				query3.addCriteria(Criteria.where("id").is(userSub.getSubId()));

				PlansDetails planDetails = this.mongoTemplate.findOne(query3, PlansDetails.class);

				if (planDetails != null)
				{
					allowedDevices = planDetails.getSupportDevices();
				}
			}

			List<Device> devices = userLoginDevicesData.getDevices();
			boolean status = true;
			for (Device device : devices)
			{
				if (device.getDeviceID().equals(deviceID))
				{
					status = false;
					break;
				}
			}

			if (!status)
			{
				result = "SUCCESS";
			}

			else if (status)
			{

				if (allowedDevices > devices.size())
				{
					device.setDeviceID(deviceID);
					device.setToken("");
					device.setOsType(osType);
					device.setLoginTime(new java.util.Date());

					devices.add(device);

					Update update = new Update();
					update.set("devices", devices);
					Query query1 = new Query();
					query1.addCriteria(Criteria.where("userId").is(userId));

					this.mongoTemplate.upsert(query1, update, UserLoginDevices.class);

					result = "SUCCESS";

				}
				else
				{
					result = "FAIL";
				}

			}

		}
		return result;

	}

	public String updateToken(User user)
	{
		String result = null;

		if (user != null)
		{
			if (user.getId() != null && user.getType() == 2 && user.getDeviceID() != null && user.getToken() != null)
			{

				Query query = new Query();
				query.addCriteria(Criteria.where("userId").is(user.getId()));

				UserLoginDevices logInDevices = this.mongoTemplate.findOne(query, UserLoginDevices.class);

				if (logInDevices != null)
				{
					if (logInDevices.getDevices() != null && logInDevices.getDevices().size() > 0)
					{
						for (int i = 0; i < logInDevices.getDevices().size(); i++)
						{
							if (logInDevices.getDevices().get(i).getDeviceID().equals(user.getDeviceID()))
							{
								logInDevices.getDevices().get(i).setToken(user.getToken());

								Update update = new Update();
								update.set("devices", logInDevices.getDevices());

								this.mongoTemplate.upsert(query, update, UserLoginDevices.class);

								result = "SUCCESS";
							}
							else
							{
								result = "INVALID_DEVICEID";
							}
						}
					}
					else
					{

					}

				}
				else
				{
					result = "INVALID_USER";
				}
			}
			else
			{
				result = "INVALID";
			}
		}
		else
		{
			result = "INVALID";
		}
		return result;
	}

	public UserLoginDevices getDeviceDetails(String uId)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("userId").is(uId));

		return this.mongoTemplate.findOne(query, UserLoginDevices.class);
	}

	public HashMap<String, String> getToken(User getToken)
	{

		HashMap<String, String> result = new HashMap<>();

		if (getToken != null)
		{
			if (getToken.getId() != null && getToken.getDeviceID() != null)
			{
				UserLoginDevices devicesData = this.getDeviceDetails(getToken.getId());

				if (devicesData != null)
				{
					if (devicesData.getDevices() != null && devicesData.getDevices().size() > 0)
					{
						for (int i = 0; i < devicesData.getDevices().size(); i++)
						{

							if (devicesData.getDevices().get(i).getDeviceID().equals(getToken.getDeviceID()))
							{
								result.put("id", devicesData.getId());
								result.put("deviceID", devicesData.getDevices().get(i).getDeviceID());
								result.put("token", devicesData.getDevices().get(i).getToken());
								result.put("response", "SUCCESS");

								return result;
							}
							else
							{
								// response = "INVALID";
							}
						}
					}
					else
					{
						result.put("response", "INVALID");
						// response = "INVALID";
					}
				}
				else
				{
					result.put("response", "INVALID_USER");
					// response = "INVALID_USER";
				}
			}
			else
			{
				result.put("response", "VALID");
				// response = "INVALID";
			}
		}
		else
		{
			result.put("response", "INVALID");
			// response = "INVALID";
		}
		return result;
	}

	private void updateOTP(User user)
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(user.getId()));

		Update update = new Update();

		// setting OTP expire time
		Calendar time = Calendar.getInstance();
		time.setTime(new java.util.Date());

		time.add(Calendar.MINUTE, 10);

		update.set("otpExpireTime", time.getTime());

		if ((user.getOtp() != null) && (user.getOtp().length() == 5))
		{
			update.set("otp", user.getOtp());

		}

		if ((user.getModifiedTime() == null))
		{
			Date dt = new java.util.Date();

			update.set("modifiedTime", dt);

		}

		this.mongoTemplate.findAndModify(query, update, User.class);

	}

	public User getUserByIdCustomized(String userId)
	{
		Query listQry = new Query();

		listQry.addCriteria(Criteria.where("id").is(userId).andOperator(Criteria.where("status").is(0)));
		listQry.fields().include("id");
		listQry.fields().include("name");
		listQry.fields().include("type");
		listQry.fields().include("address1");
		listQry.fields().include("address2");
		listQry.fields().include("city");
		listQry.fields().include("state");
		listQry.fields().include("country");
		listQry.fields().include("zip");
		listQry.fields().include("emailOTP");
		listQry.fields().include("phoneOTP");
		listQry.fields().include("icon");
		listQry.fields().include("activation");

		return this.mongoTemplate.findOne(listQry, User.class);
	}

	public String verifyDeviceId(ConsumerBusinessDetails consumer)
	{

		ConsumerBusinessDetails conBusData = getConsumerBusinessDetails(consumer.getMacId());
		if (conBusData != null)
		{
			if (consumer.getMacId().equals(conBusData.getMacId()))
			{
				return conBusData.getId();

			}
			else
			{
				return null;
			}

		}
		else
		{
			return null;
		}

	}

	public void updateTrackReport(TrackReport tReport)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(tReport.getId()));
		Update update = new Update();
		if ((tReport.getResponce() != null))
		{
			update.set("responce", tReport.getResponce());
		}
		this.mongoTemplate.findAndModify(query, update, TrackReport.class);
	}

}
