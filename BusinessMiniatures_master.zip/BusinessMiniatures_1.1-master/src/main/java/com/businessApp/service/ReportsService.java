package com.businessApp.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.businessApp.bean.AppointmentBean;
import com.businessApp.bean.BusinessReport;
import com.businessApp.model.AppointmentCalendar;
import com.businessApp.model.ConsumerBusinessDetails;
import com.businessApp.model.PublisherBusiness;
import com.businessApp.model.User;
import com.businessApp.model.UserSubDetails;
import com.businessApp.model.UserSubscriptions;

@Service
public class ReportsService
{

	private static Logger logger = LoggerFactory.getLogger(ReportsService.class);

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	PublisherService publisherService;

	@Autowired
	BusinessService businessService;

	@Autowired
	SubscriptionService subService;

	public Object totalUsersCount(AppointmentBean appointmentBean)
	{
		Map<String, Object> result = new HashMap<>();

		if (appointmentBean.getReportId() == 2)
		{
			Query query = new Query();
			query.addCriteria(Criteria.where("type").is(appointmentBean.getReportId()));

			List<User> users = this.mongoTemplate.find(query, User.class);

			result.put("name", "publishers count");
			result.put("reportName", "total publishers count");
			result.put("count", users.size());
		}
		else
		{
			List<ConsumerBusinessDetails> users = this.mongoTemplate.findAll(ConsumerBusinessDetails.class);

			result.put("name", "consumers count");
			result.put("reportName", "total consumers count");
			result.put("count", users.size());
		}

		// if(appointmentBean.getReportId()==2)
		// {
		// result.put("reportName", "total publishers count");
		// result.put("publishersCount", users.size());
		// }
		// else
		// {
		// result.put("reportName", "total consumers count");
		// result.put("consumersCount", users.size());
		// }

		return result;
	}

	// date to date
	public Object dateToDateReport(AppointmentBean appointmentBean)
	{
		if (appointmentBean.getStartScheduledTime() != null && appointmentBean.getEndScheduledTime() != null)
		{
			Map<String, Object> result = new HashMap<>();

			if (appointmentBean.getTypeId() == 14)
			{
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(appointmentBean.getStartScheduledTime());

				int year = calendar.get(Calendar.YEAR);
				calendar.set(year, 0, 1, 0, 0);
				Date startDate = calendar.getTime();
				appointmentBean.setStartScheduledTime(startDate);
				logger.info("START DATE----->" + startDate.toString());

				Calendar calendar2 = Calendar.getInstance();
				calendar2.setTime(startDate);
				calendar2.add(Calendar.YEAR, 1);

				Date endDate = calendar2.getTime();

				appointmentBean.setStartScheduledTime(startDate);
				appointmentBean.setEndScheduledTime(endDate);
			}
			else if (appointmentBean.getTypeId() == 15)
			{
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(appointmentBean.getEndScheduledTime());
				calendar.add(Calendar.DAY_OF_YEAR, 1);

				appointmentBean.setEndScheduledTime(calendar.getTime());
			}
			logger.info("END DATE---->" + appointmentBean.getEndScheduledTime());

			Query query = new Query();

			if (appointmentBean.getReportId() == 2)
			{
				query.addCriteria(Criteria.where("type").is(appointmentBean.getReportId())
				        .andOperator(Criteria.where("createdTime").gte(appointmentBean.getStartScheduledTime()))
				        .and("createdTime").lt(appointmentBean.getEndScheduledTime()));

				List<User> users = this.mongoTemplate.find(query, User.class);

				result.put("reportName", "total publishers count");
				result.put("count", users.size());
			}
			else
			{
				query.addCriteria(Criteria.where("createdTime").gte(appointmentBean.getStartScheduledTime())
				        .andOperator(Criteria.where("createdTime").lt(appointmentBean.getEndScheduledTime())));

				List<ConsumerBusinessDetails> users = this.mongoTemplate.find(query, ConsumerBusinessDetails.class);

				result.put("reportName", "total consumers count");
				result.put("count", users.size());
			}

			if (appointmentBean.getTypeId() == 11)
			{
				result.put("name", new SimpleDateFormat("dd-MM-yyyy").format(appointmentBean.getStartScheduledTime()));
			}
			else if (appointmentBean.getTypeId() == 12)
			{
				result.put("name", new SimpleDateFormat("dd-MM-yyyy").format(appointmentBean.getStartScheduledTime()));
			}
			else if (appointmentBean.getTypeId() == 13)
			{
				result.put("name", new SimpleDateFormat("MMM").format(appointmentBean.getStartScheduledTime()));
			}
			else if (appointmentBean.getTypeId() == 14)
			{
				result.put("name", new SimpleDateFormat("yyyy").format(appointmentBean.getStartScheduledTime()));
			}
			else
			{
				result.put("name", "custom");
			}
			// result.put("name", "");

			return result;
		}
		else
		{
			return "invalid";
		}

	}

	// weekly report
	public Object weeklyReport(AppointmentBean appointmentBean)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(appointmentBean.getStartScheduledTime());
		cal.add(Calendar.DAY_OF_YEAR, -7);

		Date startDate = cal.getTime();
		Date endDate = null;

		List<Object> week = new ArrayList<>();

		for (int i = 0; i < 7; i++)
		{
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(startDate);
			calendar.add(Calendar.DATE, 1);

			endDate = calendar.getTime();
			appointmentBean.setStartScheduledTime(startDate);
			appointmentBean.setEndScheduledTime(endDate);

			logger.info("" + appointmentBean.getStartScheduledTime() + "-----" + appointmentBean.getEndScheduledTime());

			Object day = dateToDateReport(appointmentBean);

			week.add(day);

			startDate = endDate;
		}
		return week;
	}

	// monthly report
	public Object monthlyReport(AppointmentBean appointmentBean)
	{
		List<Object> result = new ArrayList<>();

		Calendar c1 = Calendar.getInstance();
		c1.setTime(appointmentBean.getStartScheduledTime());
		c1.set(Calendar.DAY_OF_MONTH, 1);

		Calendar c2 = Calendar.getInstance();

		for (int month = 0; month < 12; month++)
		{
			c1.set(Calendar.MONTH, month);
			Date startDate = c1.getTime();
			appointmentBean.setStartScheduledTime(startDate);

			logger.info("THE START DATE IS-----> " + startDate.toString());

			c2.setTime(startDate);
			c2.add(Calendar.MONTH, 1);

			Date endDate = c2.getTime();
			appointmentBean.setEndScheduledTime(endDate);

			logger.info("THE END DATE IS-----> " + endDate.toString());

			Object singleMonth = dateToDateReport(appointmentBean);

			result.add(singleMonth);

		}

		return result;
	}

	public List<User> totalPublishers()
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("type").is(2));

		List<User> users = this.mongoTemplate.find(query, User.class);

		return users;
	}

	public List<User> totalPublishersByCountry(String country)
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("type").is(2).andOperator(Criteria.where("country").is(country)));

		List<User> users = this.mongoTemplate.find(query, User.class);

		return users;
	}

	public Object consumersForEachPublisher(AppointmentBean appointmentBean)
	{
		List<User> publishers;
		if (appointmentBean.getCountry() != null)
		{
			if (appointmentBean.getCountry() == "")
			{
				publishers = totalPublishers();
			}
			else
			{
				publishers = totalPublishersByCountry(appointmentBean.getCountry());
			}
		}
		else
		{
			publishers = totalPublishers();
		}
		// List<User> publishers=totalPublishers(appointmentBean);

		List<Object> result = new ArrayList<>();

		if (publishers.size() > 0)
		{
			for (int i = 0; i < publishers.size(); i++)
			{
				Map<String, Object> singlePublisher = new HashMap<>();
				logger.info("PUBLISHER " + i + "--->" + publishers.get(i).getId());
				singlePublisher.put("publisherName", publishers.get(i).getName());
				singlePublisher.put("publisherId", publishers.get(i).getId());
				singlePublisher.put("country", publishers.get(i).getCountry());
				singlePublisher.put("state", publishers.get(i).getState());
				singlePublisher.put("joinedOn",
				        new SimpleDateFormat("dd-MM-yyyy").format(publishers.get(i).getCreatedTime()));
				singlePublisher.put("phoneNumber", publishers.get(i).getPhone());
				singlePublisher.put("reportName", "publishers - consumers count");

				List<PublisherBusiness> pubBusiData = this.businessesOfPublisher(publishers.get(i).getId());
				if (pubBusiData.size() > 0)
				{
					int count = 0;

					if (appointmentBean.getTypeId() >= 10 && appointmentBean.getTypeId() <= 15)
					{
						for (int j = 0; j < pubBusiData.size(); j++)
						{
							count = count + this.consumersOfEachPublisherBusiness(appointmentBean,
							        pubBusiData.get(j).getId());
						}
					}
					else
					{
						return "invalidType";
					}

					singlePublisher.put("businessesCount", pubBusiData.size());
					singlePublisher.put("consumersCount", count);
				}
				else
				{
					singlePublisher.put("businessesCount", 0);
					singlePublisher.put("consumersCount", 0);
				}

				result.add(singlePublisher);
			}

			return result;
		}
		else
		{
			return "noPublishers";
		}

	}

	private int consumersOfEachPublisherBusiness(AppointmentBean appointmentBean, String pubBusinessId)
	{
		Query query = new Query();
		List<ConsumerBusinessDetails> consumers;
		if (appointmentBean.getTypeId() != 10)
		{
			if (appointmentBean.getTypeId() == 12)
			{
				Calendar cal = Calendar.getInstance();
				cal.setTime(appointmentBean.getStartScheduledTime());
				cal.add(Calendar.DAY_OF_YEAR, -7);

				Date startDate = cal.getTime();
				appointmentBean.setStartScheduledTime(startDate);
				appointmentBean.setEndScheduledTime(appointmentBean.getStartScheduledTime());
			}
			else if (appointmentBean.getTypeId() == 15)
			{
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(appointmentBean.getEndScheduledTime());
				calendar.add(Calendar.DAY_OF_YEAR, 1);

				appointmentBean.setEndScheduledTime(calendar.getTime());
			}
			else if (appointmentBean.getTypeId() == 14 || appointmentBean.getTypeId() == 13)
			{
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(appointmentBean.getStartScheduledTime());

				int year = calendar.get(Calendar.YEAR);
				calendar.set(year, 0, 1, 0, 0);
				Date startDate = calendar.getTime();
				appointmentBean.setStartScheduledTime(startDate);
				logger.info("START DATE----->" + startDate.toString());

				Calendar calendar2 = Calendar.getInstance();
				calendar2.setTime(startDate);
				calendar2.add(Calendar.YEAR, 1);

				Date endDate = calendar2.getTime();

				appointmentBean.setStartScheduledTime(startDate);
				appointmentBean.setEndScheduledTime(endDate);
			}

			query.addCriteria(Criteria.where("businesses").in(pubBusinessId)
			        .andOperator(Criteria.where("createdTime").gte(appointmentBean.getStartScheduledTime()))
			        .and("createdTime").lt(appointmentBean.getEndScheduledTime()));

			consumers = this.mongoTemplate.find(query, ConsumerBusinessDetails.class);
		}
		else
		{
			query.addCriteria(Criteria.where("businesses").in(pubBusinessId));

			consumers = this.mongoTemplate.find(query, ConsumerBusinessDetails.class);
		}

		if (consumers != null)
		{
			return consumers.size();
		}
		else
		{
			return 0;
		}

	}

	private List<PublisherBusiness> businessesOfPublisher(String publisherId)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("publisherId").is(publisherId));

		List<PublisherBusiness> pubBusiness = this.mongoTemplate.find(query, PublisherBusiness.class);

		return pubBusiness;

	}

	public Object revenueOfPublishers(AppointmentBean appointmentBean)
	{
		List<User> publishers;
		if (appointmentBean.getCountry() != null)
		{
			if (appointmentBean.getCountry() == "")
			{
				publishers = totalPublishers();
			}
			else
			{
				publishers = totalPublishersByCountry(appointmentBean.getCountry());
			}
		}
		else
		{
			publishers = totalPublishers();
		}

		List<Object> result = new ArrayList<>();

		if (publishers.size() > 0)
		{
			if (appointmentBean.getTypeId() >= 10 && appointmentBean.getTypeId() <= 15)
			{
				for (int i = 0; i < publishers.size(); i++)
				{
					Map<String, Object> singlePublisher = new HashMap<>();
					logger.info("PUBLISHER " + i + "--->" + publishers.get(i).getId());
					singlePublisher.put("publisherName", publishers.get(i).getName());
					singlePublisher.put("publisherId", publishers.get(i).getId());
					singlePublisher.put("country", publishers.get(i).getCountry());
					singlePublisher.put("state", publishers.get(i).getState());
					singlePublisher.put("joinedOn",
					        new SimpleDateFormat("dd-MM-yyyy").format(publishers.get(i).getCreatedTime()));
					singlePublisher.put("phoneNumber", publishers.get(i).getPhone());
					singlePublisher.put("reportName", "publishers - consumers count");

					List<PublisherBusiness> publisherBusinesses = this.businessesOfPublisher(publishers.get(i).getId());
					if (publisherBusinesses.size() > 0)
					{
						singlePublisher.put("businessesCount", publisherBusinesses.size());
						// singlePublisher.put("consumersCount", "");
						Double totalRevenue = 0.00;
						for (int j = 0; j < publisherBusinesses.size(); j++)
						{
							PublisherBusiness pbData = publisherBusinesses.get(j);
							// publisherService.getPublisherBusinessData(
							// publisherBusinesses.get(j).getId());

							Double businessRevenue = 0.00;
							List<Map<String, Object>> services = null;
							if (pbData != null)
							{
								services = revenueOfonePublisherBusiness(appointmentBean, pbData);

								if (services != null)
								{
									for (int k = 0; k < services.size(); k++)
									{
										businessRevenue = businessRevenue
										        + (Double) services.get(k).get("totalRevenue");
									}
								}

							}
							// else
							// {
							// services=null;
							// }
							//
							//
							// if (services != null)
							// {
							//
							// }
							totalRevenue = totalRevenue + businessRevenue;
						}
						singlePublisher.put("totalRevenue", totalRevenue);
					}
					else
					{
						singlePublisher.put("businessesCount", 0);
						singlePublisher.put("totalRevenue", 0);
					}
					result.add(singlePublisher);
				}
				return result;
			}
			else
			{
				return "invalidType";
			}
		}
		else
		{
			return "noPublishers";
		}

	}

	public List<Map<String, Object>> revenueOfonePublisherBusiness(AppointmentBean appointmentBean,
	        PublisherBusiness pbData)
	{

		List<Map<String, Object>> basedOnService = new ArrayList<>();

		int status = 0;

		if (pbData.getServiceCategory().size() > 0)
		{
			for (int i = 0; i < pbData.getServiceCategory().size(); i++)
			{
				if (pbData.getServiceCategory().get(i).getService().size() > 0)
				{
					status = status + 1;

					for (int j = 0; j < pbData.getServiceCategory().get(i).getService().size(); j++)
					{
						String serviceId = pbData.getServiceCategory().get(i).getService().get(j).getId();
						// Double serviceCost =
						// pbData.getServiceCategory().get(i)
						// .getService().get(j).getPrice();
						Query query2 = new Query();

						if (appointmentBean.getTypeId() != 10)
						{

							if (appointmentBean.getTypeId() == 12)
							{
								Calendar cal = Calendar.getInstance();
								cal.setTime(appointmentBean.getStartScheduledTime());
								cal.add(Calendar.DAY_OF_YEAR, -7);

								Date startDate = cal.getTime();
								appointmentBean.setStartScheduledTime(startDate);
								appointmentBean.setEndScheduledTime(appointmentBean.getStartScheduledTime());
							}
							else if (appointmentBean.getTypeId() == 15)
							{
								Calendar calendar = Calendar.getInstance();
								calendar.setTime(appointmentBean.getEndScheduledTime());
								calendar.add(Calendar.DAY_OF_YEAR, 1);

								appointmentBean.setEndScheduledTime(calendar.getTime());
							}
							else if (appointmentBean.getTypeId() == 14 || appointmentBean.getTypeId() == 13)
							{
								Calendar calendar = Calendar.getInstance();
								calendar.setTime(appointmentBean.getStartScheduledTime());

								int year = calendar.get(Calendar.YEAR);
								calendar.set(year, 0, 1, 0, 0);
								Date startDate = calendar.getTime();
								appointmentBean.setStartScheduledTime(startDate);
								logger.info("START DATE----->" + startDate.toString());

								Calendar calendar2 = Calendar.getInstance();
								calendar2.setTime(startDate);
								calendar2.add(Calendar.YEAR, 1);

								Date endDate = calendar2.getTime();

								appointmentBean.setStartScheduledTime(startDate);
								appointmentBean.setEndScheduledTime(endDate);
							}

							query2.addCriteria(Criteria.where("serviceId").is(serviceId)
							        .andOperator(Criteria.where("businessId").is(pbData.getId()))
							        .and("startScheduledTime").gte(appointmentBean.getStartScheduledTime())
							        .and("endScheduledTime").lt(appointmentBean.getEndScheduledTime()));
						}
						else
						{
							query2.addCriteria(Criteria.where("serviceId").is(serviceId)
							        .andOperator(Criteria.where("businessId").is(pbData.getId())));
						}

						// query2.addCriteria(Criteria.where("serviceId")
						// .is(serviceId)
						// .andOperator(Criteria.where("businessId")
						// .is(appointmentBean.getBusinessId()))
						// .and("startScheduledTime")
						// .gte(appointmentBean.getStartScheduledTime())
						// .and("endScheduledTime")
						// .lt(appointmentBean.getEndScheduledTime()));

						List<AppointmentCalendar> serviceAppointments = this.mongoTemplate.find(query2,
						        AppointmentCalendar.class);

						int performedAppointments = 0;
						int canceledAppointments = 0;
						double totalRevenue = 0.00;

						if (serviceAppointments != null && serviceAppointments.size() > 0)
						{
							for (int k = 0; k < serviceAppointments.size(); k++)
							{
								if (serviceAppointments.get(k).getStatus() == 2)
								{
									totalRevenue = totalRevenue + serviceAppointments.get(k).getPrice();
									performedAppointments = performedAppointments + 1;
								}
								if (serviceAppointments.get(k).getStatus() == 3)
								{
									canceledAppointments = canceledAppointments + 1;
								}
							}
						}

						Map<String, Object> serviceReport = new HashMap<>();
						// serviceReport.put("serviceCategoryName", pbData
						// .getServiceCategory().get(i).getName());
						// serviceReport.put("serviceId", serviceId);
						// serviceReport.put("serviceName",
						// pbData.getServiceCategory().get(i)
						// .getService().get(j).getName());
						if (serviceAppointments != null && serviceAppointments.size() > 0)
						{
							serviceReport.put("scheduledAppointmentsCount", serviceAppointments.size());
						}
						else
						{
							serviceReport.put("scheduledAppointmentsCount", 0);
						}

						serviceReport.put("performedAppointmentsCount", performedAppointments);
						serviceReport.put("canceledAppointmentsCount", canceledAppointments);
						serviceReport.put("totalRevenue", totalRevenue);

						basedOnService.add(serviceReport);
					}
				}
			}
			if (status == 0)
			{
				return null;
			}
			else
			{
				return basedOnService;
			}
		}
		else
		{
			return null;
		}

	}

	public Object getBusinessEnqiryReport(BusinessReport businessReport)
	{

		List<Map<String, String>> response = new ArrayList<>();

		if (businessReport != null)
		{
			if (businessReport.getBusinessId() != null)
			{
				Query query = new Query();

				if (businessReport.getEndDate().toString() != "")
				{
					Calendar cal = Calendar.getInstance();
					cal.setTime(businessReport.getEndDate());
					cal.add(Calendar.DAY_OF_YEAR, 1);

					businessReport.setEndDate(cal.getTime());
				}

				if (businessReport.getCountry() != "" && businessReport.getState() != ""
				        && businessReport.getStartDate().toString() != ""
				        && businessReport.getEndDate().toString() != "")
				{
					query.addCriteria(Criteria.where("businessId").is(businessReport.getBusinessId())
					        .andOperator(Criteria.where("country").is(businessReport.getCountry())).and("state")
					        .is(businessReport.getState()).and("createdTime").gte(businessReport.getStartDate())
					        .and("createdTime").lte(businessReport.getEndDate()).and("status").is(0));
				}
				else if (businessReport.getCountry() != "" && businessReport.getState() != ""
				        && businessReport.getStartDate().toString() == ""
				        && businessReport.getEndDate().toString() == "")
				{
					query.addCriteria(Criteria.where("businessId").is(businessReport.getBusinessId())
					        .andOperator(Criteria.where("country").is(businessReport.getCountry())).and("state")
					        .is(businessReport.getState()).and("status").is(0));
				}
				else if (businessReport.getCountry() != "" && businessReport.getState() == ""
				        && businessReport.getStartDate().toString() != ""
				        && businessReport.getEndDate().toString() != "")
				{
					query.addCriteria(Criteria.where("businessId").is(businessReport.getBusinessId())
					        .andOperator(Criteria.where("country").is(businessReport.getCountry()).and("createdTime")
					                .gte(businessReport.getStartDate()))
					        .and("createdTime").lte(businessReport.getEndDate()).and("status").is(0));
				}
				else if (businessReport.getCountry() == "" && businessReport.getState() == ""
				        && businessReport.getStartDate().toString() != ""
				        && businessReport.getEndDate().toString() != "")
				{
					query.addCriteria(Criteria.where("businessId").is(businessReport.getBusinessId())
					        .andOperator(Criteria.where("createdTime").gte(businessReport.getStartDate()))
					        .and("createdTime").lte(businessReport.getEndDate()).and("status").is(0));
				}
				else if (businessReport.getCountry() != "" && businessReport.getState() == ""
				        && businessReport.getStartDate().toString() == ""
				        && businessReport.getEndDate().toString() == "")
				{
					query.addCriteria(Criteria.where("businessId").is(businessReport.getBusinessId()).andOperator(
					        Criteria.where("country").is(businessReport.getCountry()).and("status").is(0)));
				}
				else
				{
					query.addCriteria(Criteria.where("businessId").is(businessReport.getBusinessId())
					        .andOperator(Criteria.where("status").is(0)));
				}

				query.fields().include("id");
				query.fields().include("businessId");
				query.fields().include("publisherId");
				query.fields().include("createdTime");
				query.fields().include("country");
				query.fields().include("state");

				List<PublisherBusiness> pbData = this.mongoTemplate.find(query, PublisherBusiness.class);

				if (pbData != null && pbData.size() > 0)
				{
					for (int j = 0; j < pbData.size(); j++)
					{
						Map<String, String> result = new HashMap<>();

						Query query2 = new Query();

						if (businessReport.getPlan() != "")
						{
							query2.addCriteria(Criteria.where("uId").is(pbData.get(j).getPublisherId())
							        .andOperator(Criteria.where("subId").is(businessReport.getPlan())));
						}
						else
						{
							query2.addCriteria(Criteria.where("uId").is(pbData.get(j).getPublisherId()));

						}

						UserSubscriptions userSub = this.mongoTemplate.findOne(query2, UserSubscriptions.class);

						if (userSub != null)
						{
							Query query3 = new Query();
							query3.addCriteria(Criteria.where("pubId").is(userSub.getuId())
							        .andOperator(Criteria.where("planStartTime").is(userSub.getPlanStartTime())));

							UserSubDetails userSubDetails = this.mongoTemplate.findOne(query3, UserSubDetails.class);

							Query query5 = new Query();
							query5.addCriteria(Criteria.where("businessId").is(pbData.get(j).getId()));

							List<AppointmentCalendar> appointments = this.mongoTemplate.find(query5,
							        AppointmentCalendar.class);

							if (businessReport.getType().equalsIgnoreCase("businessEnquiryReport"))
							{
								Query query4 = new Query();
								query4.addCriteria(Criteria.where("businesses").in(pbData.get(j).getId()));

								List<ConsumerBusinessDetails> cbData = this.mongoTemplate.find(query4,
								        ConsumerBusinessDetails.class);

								double revenue = 0;
								if (appointments != null && appointments.size() > 0)
								{
									for (int i = 0; i < appointments.size(); i++)
									{
										if (appointments.get(i).getStatus() == 2)
										{
											revenue = revenue + appointments.get(i).getPrice();
										}
									}
								}

								result.put("numberOfConsumers", String.valueOf(cbData.size()));
								result.put("revenue", String.valueOf(revenue));
							}
							else if (businessReport.getType().equalsIgnoreCase("appointmentStatus"))
							{
								int performedAppointments = 0, cancelledAppointments = 0;

								if (appointments != null && appointments.size() > 0)
								{
									for (int i = 0; i < appointments.size(); i++)
									{
										if (appointments.get(i).getStatus() == 2)
										{
											performedAppointments = performedAppointments + 1;
										}
										if (appointments.get(i).getStatus() == 3)
										{
											cancelledAppointments = cancelledAppointments + 1;
										}
									}
								}

								result.put("scheduledAppointments", String.valueOf(appointments.size()));
								result.put("performedAppointments", String.valueOf(performedAppointments));
								result.put("cancelledAppointments", String.valueOf(cancelledAppointments));
							}

							result.put("publisherId", pbData.get(j).getId());
							result.put("business", businessService
							        .getTemplateBusinessDetails(pbData.get(j).getBusinessId()).getName());
							result.put("plan", subService.getSubscriptionDetails(userSub.getSubId()).getType());
							result.put("status", "NA");
							result.put("startDate",
							        new SimpleDateFormat("dd-MM-yyyy").format(pbData.get(j).getCreatedTime()));
							result.put("country", pbData.get(j).getCountry());
							result.put("state", pbData.get(j).getState());
							result.put("numberOfBusinesses", String.valueOf(userSubDetails.getBusinesses().size()));

							response.add(result);
						}

					}

					return response;
				}
				else
				{
					return "NO_BUSINESSES";
				}

			}
			else
			{
				return "INVALID";
			}
		}
		else
		{
			return "INVALID";
		}
	}

}