package com.businessApp.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.businessApp.model.PlansDetails;

@Transactional
public interface SubscriptionSettingsRepository
		extends
			MongoRepository<PlansDetails, Long>
{

}
