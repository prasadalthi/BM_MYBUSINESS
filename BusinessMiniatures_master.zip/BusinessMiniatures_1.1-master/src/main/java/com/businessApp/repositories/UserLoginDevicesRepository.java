package com.businessApp.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.businessApp.model.UserLoginDevices;

public interface UserLoginDevicesRepository extends MongoRepository<UserLoginDevices, Long>
{

}