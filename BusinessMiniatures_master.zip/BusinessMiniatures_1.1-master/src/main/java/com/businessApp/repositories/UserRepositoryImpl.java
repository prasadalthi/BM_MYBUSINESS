package com.businessApp.repositories;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.web.util.UriComponentsBuilder;

import com.businessApp.bean.LoginResult;
import com.businessApp.bean.UserBean;
import com.businessApp.model.User;
import com.businessApp.service.*;
import com.businessApp.model.*;
import com.businessApp.util.EncryptUtil;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

public class UserRepositoryImpl implements CustomUserRepository
{
	private static Logger logger = LoggerFactory.getLogger(UserRepositoryImpl.class);

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Autowired
	LoginResult loginResult;
	
	@Autowired
	PublisherService publisherService;
	
	@Autowired
	SubscriptionService subService;

    @Override
    public Map<String, String> saveUser(User user) throws Exception
	 {
	 Map<String, String> userData = new HashMap<>();
	
	 if (user.getPassword() != null)
	 {
	
      user.setPassword(EncryptUtil.encrypt(user.getPassword()));
	 }
	
	if (user.getType() == 2)
	 {
	  //Generate OTP
	 UserService userservice=new UserService();
	 char[] otp = userservice.generateOTP(5);
	
	 String otpStr = new String(otp);
	 user.setOtp(otpStr);
	 }
	
	 this.mongoTemplate.save(user);
	
	 userData.put("id", user.getId());
	 userData.put("message", "SUCCESS");
	 return userData;
	 }

	@Override
	public List<User> listUser(int type) throws Exception
	{

		List<Object> tmp = new ArrayList<>();

		Query query = new Query();

		query.addCriteria(Criteria.where("type").is(type).andOperator(Criteria.where("status").is(0)));

		query.fields().include("id");
		query.fields().include("name");
		query.fields().include("type");
		query.fields().include("address1");
		query.fields().include("address2");
		query.fields().include("city");
		query.fields().include("state");
		query.fields().include("country");
		query.fields().include("zip");
		query.fields().include("phone");
		query.fields().include("email");
		query.fields().include("modifiedBy");
		query.fields().include("modifiedTime");
		query.fields().include("userId");

		List<User> users = this.mongoTemplate.find(query, User.class);

		return users;
	}

	 @Override
	 public User getUserById(String userId) throws Exception
	{
	 Query listQry = new Query();
	
	 listQry.addCriteria(Criteria.where("id").is(userId)
	 .andOperator(Criteria.where("status").is(0)));
	 listQry.fields().include("id");
	 listQry.fields().include("name");
	 listQry.fields().include("type");
	 listQry.fields().include("address1");
	 listQry.fields().include("address2");
	 listQry.fields().include("city");
	 listQry.fields().include("state");
	 listQry.fields().include("country");
	 listQry.fields().include("zip");
	 listQry.fields().include("phone");
	 listQry.fields().include("email");
	 listQry.fields().include("modifiedBy");
	 listQry.fields().include("modifiedTime");
	 listQry.fields().include("icon");
	 long count = this.mongoTemplate.count(listQry, User.class);
	
	 if (count > 0)
	 {
	
	 return this.mongoTemplate.findOne(listQry, User.class);
	 } else
	{
	 return null;
	 }
	
	}

	 @Override
	public Object updateUser(User user) throws Exception
	{

		if (user.getId() != null)
		{
			Query query = new Query();
			query.addCriteria(Criteria.where("id").is(user.getId()));
			Update update = new Update();
			if (user.getName() != null)
			{
				update.set("name", user.getName());
			}

			if (user.getCity() != null)
			{
				update.set("city", user.getCity());
			}

			if (user.getState() != null)
			{
				update.set("state", user.getState());
			}

			if (user.getCountry() != null)
			{
				update.set("country", user.getCountry());
			}

			if (user.getZip() != null)
			{
				update.set("zip", user.getZip());
			}

			if (user.getAddress1() != null)
			{
				update.set("address1", user.getAddress1());
			}

			if (user.getAddress2() != null)
			{
				update.set("address2", user.getAddress2());
			}

			if (user.getPhoneOTP() != null)
			{
				update.set("phoneOTP", user.getPhoneOTP());
			}

			if (user.getOtp() != null)
			{
				update.set("otp", user.getOtp());
			}

			if (user.getToken() != null)
			{
				update.set("token", user.getToken());
			}

			if (user.getActivation() != 0)
			{
				update.set("active", user.getActivation());
			}

			if (user.getModifiedTime() != null)
			{
				update.set("modifiedTime", user.getModifiedTime());
			}
			query.fields().exclude("phone");
			query.fields().exclude("email");
			query.fields().exclude("password");

			return this.mongoTemplate.findAndModify(query, update, User.class);

		}
		else
		{
			return null;

		}

	}

	@Override
	public String logIn(String userId) throws Exception {
		
		UserBean user=new UserBean();
		if ((user.getLogInId() != null) && ((user.getType() != 0)))
		{
			boolean loginType = phoneValidator(user.getLogInId());

			 if (loginType)
			 {
			
			 if ((loginType != true))
			 {
			 return "INVALID_LOGIN";
			 }
			
			 else
			 {
			
			 return loginUser(user);
			 
			 }
			
			 }
			
			 else
			 {
			 boolean emailValid = emailValidator(user.getLogInId());
			 if ((emailValid != true))
			 {
			
			 return "INVALID_LOGIN";
			 }
			
			 else
			 {
			
			 return loginUser(user);
			 }
			
			 }
		}
		return userId;
		
	}
	
	public boolean emailValidator(String email)
	{

		try
		{

			String emailregex = "^[A-Za-z][A-Za-z0-9!@#$.%^&*]*$";
			Boolean b = email.matches(emailregex);

			if (b == false)
			{
				return false;
			}
			else if (b == true)
			{
				return true;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();

		}
		return false;
	}

	public boolean phoneValidator(String phoneNo)
	{
		if (phoneNo.matches("\\d{10}"))
		{
			return true;
		}
		else if (phoneNo.matches("\\d{3}[-\\.\\s]\\d{3}[-\\.\\s]\\d{4}"))
		{
			return true;
		}
		else if (phoneNo.matches("\\d{3}-\\d{3}-\\d{4}\\s(x|(ext))\\d{3,5}"))
		{
			return true;
		}
		else if (phoneNo.matches("\\(\\d{3}\\)-\\d{3}-\\d{4}"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public String loginUser(UserBean user) throws Exception
	{

		int userType = user.getType();
		User userDetails = null;
		Query query = new Query();

		query.addCriteria(Criteria.where("type").is(userType).and("status").is(0)
		        .andOperator(Criteria.where("userId").is(user.getLogInId())));

		userDetails = this.mongoTemplate.findOne(query, User.class);

		if (userDetails != null)
		{
			this.loginResult.setUserData(userDetails);
			String mobileOTPResult = null, EmailOTPResult = null;

			if (userDetails.getActivation() == 0)
			{

				// generate otp string
				char[] otp = generateOTP(5);
				String otpStr = new String(otp);
				userDetails.setOtp(otpStr);
				userDetails.setModifiedTime(new java.util.Date());

				if (userDetails.getPhoneOTP() != null)
				{
					String phoneNumber = userDetails.getCountryCode() + userDetails.getPhoneOTP();
					mobileOTPResult = mobileOTPService(otpStr, phoneNumber);
				}
				if (userDetails.getEmailOTP() != null)
				{
					EmailOTPResult = SendEmailOTP(otpStr, userDetails.getEmailOTP());
				}

				if (((mobileOTPResult.equalsIgnoreCase("Success")) || (mobileOTPResult.equalsIgnoreCase("OK"))
				        || (EmailOTPResult.equalsIgnoreCase("Success"))))
				{
					Query queryt = new Query();
					queryt.addCriteria(Criteria.where("id").is(userDetails.getId()));
					Update update = new Update();

					if ((userDetails.getOtp() != null) && (otpStr.length() == 5))
					{
						update.set("otp", userDetails.getOtp());
					}

					// setting OTP expire time
					Calendar time = Calendar.getInstance();
					time.setTime(new java.util.Date());

					time.add(Calendar.MINUTE, 10);

					update.set("otpExpireTime", time.getTime());

					if (userDetails.getModifiedTime() != null)
					{
						update.set("modifiedTime", userDetails.getModifiedTime());
					}

					this.mongoTemplate.findAndModify(query, update, User.class);
				}
			}

			else if (userDetails.getActivation() == 1 || userDetails.getActivation() == 2)
			{

				Date currentTime = new Date();

				Date otpExpTime = userDetails.getOtpExpireTime();

				if (currentTime.compareTo(otpExpTime) > 0)
				{

					// generate otp string
					char[] otp = generateOTP(5);
					String otpStr = new String(otp);
					userDetails.setOtp(otpStr);
					userDetails.setModifiedTime(new java.util.Date());

					// previous OTP has been expired
					if (userDetails.getPhoneOTP() != null)
					{
						String phoneNumber = userDetails.getCountryCode() + userDetails.getPhoneOTP();
						mobileOTPResult = mobileOTPService(otpStr, phoneNumber);
					}
					if (userDetails.getEmailOTP() != null)
					{
						EmailOTPResult = SendEmailOTP(otpStr, userDetails.getEmailOTP());
					}

					if (((mobileOTPResult.equalsIgnoreCase("Success")) || (mobileOTPResult.equalsIgnoreCase("OK"))
					        || (EmailOTPResult.equalsIgnoreCase("Success"))))
					{
						Query queryt = new Query();
						queryt.addCriteria(Criteria.where("id").is(userDetails.getId()));
						Update update = new Update();

						if ((userDetails.getOtp() != null) && (otpStr.length() == 5))
						{
							update.set("otp", userDetails.getOtp());
						}

						// setting OTP expire time
						Calendar time = Calendar.getInstance();
						time.setTime(new java.util.Date());

						time.add(Calendar.MINUTE, 10);

						update.set("otpExpireTime", time.getTime());

						if (userDetails.getModifiedTime() != null)
						{
							update.set("modifiedTime", userDetails.getModifiedTime());
						}

						this.mongoTemplate.findAndModify(query, update, User.class);
					}
				}
				else
				{
					// previous OTP has not been expired
					if (userDetails.getPhoneOTP() != null)
					{
						String phoneNumber = userDetails.getCountryCode() + userDetails.getPhoneOTP();
						mobileOTPResult = mobileOTPService(userDetails.getOtp(), phoneNumber);
					}
					if (userDetails.getEmailOTP() != null)
					{
						EmailOTPResult = SendEmailOTP(userDetails.getOtp(), userDetails.getEmailOTP());
					}

				}
			}

			this.loginResult.setUserData(userDetails);

			if (userType == 2)
			{
				this.loginResult.setBusinessData(this.publisherService.businessListBypublisherId(userDetails.getId()));

				this.loginResult.setMenuData(this.subService.menuList());

			}
			else
			{
				this.loginResult.setBusinessData(null);
				this.loginResult.setMenuData(null);
			}
			return "Success";

		}

		else
		{

			return "InvalidUser";
		}
	}
	public char[] generateOTP(int len)
	{

		String numbers = "123456789";

		Random rndm_method = new Random();

		char[] otp = new char[len];

		for (int i = 0; i < len; i++)
		{

			otp[i] = numbers.charAt(rndm_method.nextInt(numbers.length()));
		}
		return otp;
	}
	
	private String mobileOTPService(String otp, String mobile)
	        throws MalformedURLException, IOException, UnirestException
	{

		String uriComponents = UriComponentsBuilder.newInstance().scheme("http").host("2factor.in")
		        .path("/API/V1/917492e3-bbfb-11e8-a895-0200cd936042/SMS/{phone_number}/{otp}/BMLOGIN").build()
		        .expand(mobile, otp).encode().toUriString();

		com.mashape.unirest.http.HttpResponse<String> response = Unirest.get(uriComponents)
		        .header("content-type", "application/x-www-form-urlencoded").asString();

		return response.getStatusText();
	}
	
	private String SendEmailOTP(String otp, String email)
	{

		return "Success";
	}

}
