package com.businessApp.repositories;

import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import com.businessApp.model.User;

@Transactional
public interface CustomUserRepository
{
	 public Object updateUser(User user) throws Exception;
	 public Map<String, String> saveUser(User user) throws Exception;
	 public List<User> listUser(int id) throws Exception;
     public User getUserById(String userId) throws Exception;
     public String logIn(String userId) throws Exception;

}
