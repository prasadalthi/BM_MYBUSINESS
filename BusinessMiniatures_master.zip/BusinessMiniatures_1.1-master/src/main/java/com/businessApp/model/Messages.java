package com.businessApp.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Component;

@Document(collection = "messages")
@Component
public class Messages
{
	@Id
	private String id;
	private String from;
	private String to;
	private String title;
	private String message;
	private String uId;
	private String bId;
	private String receiverID;
	private int status;
	private String image;

	private int type; // 0 --- Notification 1--- Message
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date createdTime;

	public String getuId()
	{
		return uId;
	}

	public void setuId(String uId)
	{
		this.uId = uId;
	}

	public String getbId()
	{
		return bId;
	}

	public void setbId(String bId)
	{
		this.bId = bId;
	}

	public String getReceiverID()
	{
		return receiverID;
	}

	public void setReceiverID(String receiverID)
	{
		this.receiverID = receiverID;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getMessage()
	{
		return message;
	}

	public void setMessage(String message)
	{
		this.message = message;
	}

	public int getType()
	{
		return type;
	}

	public void setType(int type)
	{
		this.type = type;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public Date getCreatedTime()
	{
		return createdTime;
	}

	public void setCreatedTime(Date createdTime)
	{
		this.createdTime = createdTime;
	}

	public int getStatus()
	{
		return status;
	}

	public void setStatus(int status)
	{
		this.status = status;
	}

	public String getFrom()
	{
		return from;
	}

	public void setFrom(String from)
	{
		this.from = from;
	}

	public String getTo()
	{
		return to;
	}

	public void setTo(String to)
	{
		this.to = to;
	}

	public String getImage()
	{
		return image;
	}

	public void setImage(String image)
	{
		this.image = image;
	}

	@Override
	public String toString()
	{
		return "Messages [id=" + id + ", from=" + from + ", to=" + to + ", title=" + title + ", message=" + message
		        + ", uId=" + uId + ", bId=" + bId + ", receiverID=" + receiverID + ", status=" + status + ", image="
		        + image + ", type=" + type + ", createdTime=" + createdTime + "]";
	}

}
