package com.businessApp.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Document(collection = "consumerBusinessDetails")
public class ConsumerBusinessDetails
{
	private String id;
	private String macId;
	private String tokenId;

	private List<String> businesses;
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date modifiedTime, createdTime;

	ConsumerBusinessDetails() {
		this.businesses = new ArrayList<>();
	}

	public String getId()
	{
		return this.id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getMacId()
	{
		return this.macId;
	}

	public void setMacId(String macId)
	{
		this.macId = macId;
	}

	public List<String> getBusinesses()
	{
		return this.businesses;
	}

	public void setBusinesses(List<String> businesses)
	{
		this.businesses = businesses;
	}

	public Date getModifiedTime()
	{
		return this.modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime)
	{
		this.modifiedTime = modifiedTime;
	}

	public Date getCreatedTime()
	{
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime)
	{
		this.createdTime = createdTime;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

}
