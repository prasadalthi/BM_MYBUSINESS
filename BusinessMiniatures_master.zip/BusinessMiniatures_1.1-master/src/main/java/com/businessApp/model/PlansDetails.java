package com.businessApp.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Document(collection = "PlansDetails")
public class PlansDetails
{
	@Id
	private String id;
	private String type;
	private int price;
	private String duration;
	private int businessCount;
	private int trailVersion; // 0 --> Yes ,1 ---> No
	private int supportDevices;
	private int reports;
	private int employeeManServices; // 0 --> Yes ,1 ---> No
	private int notifications;
	private int serviceAllowed;

	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date modifiedTime, createdTime;

	public int getTrailVersion()
	{
		return this.trailVersion;
	}

	public void setTrailVersion(int trailVersion)
	{
		this.trailVersion = trailVersion;
	}

	public int getSupportDevices()
	{
		return this.supportDevices;
	}

	public void setSupportDevices(int supportDevices)
	{
		this.supportDevices = supportDevices;
	}

	public int getReports()
	{
		return this.reports;
	}

	public void setReports(int reports)
	{
		this.reports = reports;
	}

	public int getEmployeeManServices()
	{
		return this.employeeManServices;
	}

	public void setEmployeeManServices(int employeeManServices)
	{
		this.employeeManServices = employeeManServices;
	}

	public int getNotifications()
	{
		return this.notifications;
	}

	public void setNotifications(int notifications)
	{
		this.notifications = notifications;
	}

	public int getServiceAllowed()
	{
		return this.serviceAllowed;
	}

	public void setServiceAllowed(int serviceAllowed)
	{
		this.serviceAllowed = serviceAllowed;
	}

	public String getId()
	{
		return this.id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public Date getModifiedTime()
	{
		return this.modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime)
	{
		this.modifiedTime = modifiedTime;
	}

	public Date getCreatedTime()
	{
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime)
	{
		this.createdTime = createdTime;
	}

	public String getType()
	{
		return this.type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public int getPrice()
	{
		return this.price;
	}

	public void setPrice(int price)
	{
		this.price = price;
	}

	public String getDuration()
	{
		return this.duration;
	}

	public void setDuration(String duration)
	{
		this.duration = duration;
	}

	public int getBusinessCount()
	{
		return this.businessCount;
	}

	public void setBusinessCount(int businessCount)
	{
		this.businessCount = businessCount;
	}

}
