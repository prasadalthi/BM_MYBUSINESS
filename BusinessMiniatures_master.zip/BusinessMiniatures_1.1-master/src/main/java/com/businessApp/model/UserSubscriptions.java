package com.businessApp.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Component;

@Document(collection = "userSubscriptions")
@Component
public class UserSubscriptions
{

	@Id
	private String id;
	private String uId;
	private String subId;
	// private String planId;
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date planStartTime, planEndTime;

	public String getuId()
	{
		return uId;
	}

	public void setuId(String uId)
	{
		this.uId = uId;
	}

	public Date getPlanStartTime()
	{
		return planStartTime;
	}

	public void setPlanStartTime(Date planStartTime)
	{
		this.planStartTime = planStartTime;
	}

	public Date getPlanEndTime()
	{
		return planEndTime;
	}

	public void setPlanEndTime(Date planEndTime)
	{
		this.planEndTime = planEndTime;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	// public String getPlanId()
	// {
	// return planId;
	// }
	//
	// public void setPlanId(String planId)
	// {
	// this.planId = planId;
	// }

	public String getSubId()
	{
		return subId;
	}

	public void setSubId(String subId)
	{
		this.subId = subId;
	}

}
